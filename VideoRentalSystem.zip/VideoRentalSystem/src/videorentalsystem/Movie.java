/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.util.ArrayList;
import java.util.Date;


//String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};

public class Movie {
  
    public Integer id;
    public String title;
    public Actor director;
    public ArrayList<Actor> as_list;
    public String year;
    public String genre;
    public String studio;
    
    public String poster_path;
        
    public int quantity=10;
    public Double price=10.0;
    
    public static ArrayList<Movie> movies=new ArrayList<Movie>();
    
    Movie(Integer id,String title,Actor director,ArrayList<Actor> a_list,String year,String genre,String studio,String poster_path,double price)
    {
        this.id=id;
        this.title=title;
        this.director=director;
        this.as_list=a_list;
        this.year=year;
        this.genre=genre;
        this.studio=studio;
        
        this.poster_path=poster_path;
        this.price=price;
        
        boolean exists=false;
        
        for(Movie m:movies){
            if(m.id==id) exists=true;
        }
        
        if(exists==false) movies.add(this);
        
    }
    
    public static Movie getMovieByTitle(String title)
    {
        for(Movie m:movies)
        {
            if(m.title.equals(title)) {return m;};
        }
        return null;
    }
    
    public static void showMovies()
    {
        System.out.println("Id     Title     Director     Actors     Year          Genre         Studio");
        for(Movie m:movies)
        {
        System.out.print(""+m.id);
        System.out.print("     "+m.title);
        
        System.out.print("     "+m.director.name);
            
        if(m.as_list.size()==1){
            System.out.print("     "+m.as_list.get(0).name);
        }
        if(m.as_list.size()==2){
            System.out.print("     "+m.as_list.get(0).name+" "+m.as_list.get(1).name);
        }
        System.out.print("     "+m.year);
        System.out.print("     "+m.genre);
        System.out.print("     "+m.studio);
        System.out.println("");
        }
    }
    
}
