/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.util.ArrayList;
import java.util.Date;


//String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};

public class Person {
  
    public Integer id;
    public String name;
    public String surname;
    public String birth_date;
    public String address;
    public String city;
    public String email;
    public String phone;
    
    public int unreturned_movies=0;
    
    public Transaction current_transaction;
    
    public ArrayList<Transaction> transaction_list=new ArrayList<Transaction>();
    
    public static ArrayList<Person> persons=new ArrayList<Person>();
    
    Person(Integer id,String name,String surname,String birth_date,String address,String city,String email,String phone)
    {
        this.id=id;
        this.name=name;
        this.surname=surname;
        this.birth_date=birth_date;
        this.address=address;
        this.city=city;
        this.email=email;
        this.phone=phone;
        
        boolean exists=false;
        
        for(Person p:persons){
            if(p.id==id) exists=true;
        }
        
        if(exists==false) persons.add(this);
        
    }
    
    public void calculate_unreturnedMovies()
    {
        unreturned_movies=0;
        for(Transaction t:transaction_list)
        {
            
            if(t.transaction_closed==false)
            {
                unreturned_movies=unreturned_movies+t.items.size();
            }
        }
        System.out.println(unreturned_movies);
    }
    
    public static Person getCustomer(int id)
    {
        Person ret_p=null;
        
        for(Person p:persons)
        {
            if(p.id==id)
            {
                ret_p=p;
            }
        }
        return ret_p;
    }
    
    public static void showPersons()
    {
        System.out.println("Id     Name     Surname     Birth     Address          City         Email              Phone");
        for(Person p:persons)
        {
        System.out.print(""+p.id);
        System.out.print("     "+p.name);
        System.out.print("     "+p.surname);
        System.out.print("     "+p.birth_date);
        System.out.print("     "+p.address);
        System.out.print("     "+p.city);
        System.out.print("     "+p.email);
        System.out.print("     "+p.phone);
        System.out.println("");
        }
    }
    
}
