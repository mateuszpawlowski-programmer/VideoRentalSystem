/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;


//String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};

public class Person implements Serializable{
  
    private static final long SerialVersionUID = 10l;
    
    public Integer id;
    public String name;
    public String surname;
    public String birth_date;
    public String address;
    public String city;
    public String email;
    public String phone;
    
    public boolean deleted=false;
    
    public int unreturned_movies=0;
    
    public Transaction current_transaction;
    
    public ArrayList<Transaction> transaction_list=new ArrayList<Transaction>();
    
    public static ArrayList<Person> persons=new ArrayList<Person>();
    
    Person(Integer id,String name,String surname,String birth_date,String address,String city,String email,String phone)
    {
        this.id=id;
        this.name=name;
        this.surname=surname;
        this.birth_date=birth_date;
        this.address=address;
        this.city=city;
        this.email=email;
        this.phone=phone;
        
        boolean exists=false;
        
        for(Person p:persons){
            if(p.id==id) exists=true;
        }
        
        if(exists==false) persons.add(this);
        
    }
    
    public static void saveAllPersons()
    {
        try{
            System.out.println("saveAllPersons()");

            for(Person p:persons)
            {
                System.out.println("Save person: "+p.id);
                p.savePerson();
            }
        }catch(Exception exc){System.out.println("Exception: "+exc);}
    }
    
    public void savePerson()
    {
        try{
            FileOutputStream fos 
                = new FileOutputStream("Person_id_"+this.id+".txt"); 
            ObjectOutputStream oos 
                = new ObjectOutputStream(fos); 
            oos.writeObject(this); 
            oos.close(); 
        }catch(Exception exc){System.out.println("Exception: "+exc);}
    }
    
    public static void loadAllPersons()
    {
        //loadPerson(1);
        
        //int nr=11;
        
        for(int nr=1;nr<1000;nr++){
                    try{
                        FileInputStream fis 
                            = new FileInputStream("Person_id_"+nr+".txt"); 
                        ObjectInputStream ois = new ObjectInputStream(fis); 


                        System.out.println("number "+nr);

                        Person.loadPerson_2(nr);
                    }catch(Exception exc)
                    {
                        //System.out.println("error "+exc);
                    }
        }
        VideoRentalSystem.ref.updateUsersTable();
    }
    
    public static void loadPerson_2(int id)
    {
        try{
        FileInputStream fis 
            = new FileInputStream("Person_id_"+id+".txt"); 
        ObjectInputStream ois = new ObjectInputStream(fis); 
        
        Person p=(Person)ois.readObject();
        ois.close(); 
        
        if(p.deleted==false){
            Person.persons.add(p);
        }
        
        System.out.println("Load person: "+p.id+" "+p.name+p.surname+p.address+p.birth_date+p.email+p.phone);
        System.out.println("p.deleted="+p.deleted);
        //new Person(10,"Albert","Einstein","1879","Germany","Ulm","albert_einstein@mail.com","123-321-123");
        
        /*
        if(p.deleted==false){
                new Person(p.id,p.name,p.surname,p.birth_date,p.address,p.city,p.email,p.phone);
                //EnterNewCustomer.maxId=10;
                EnterNewCustomer.maxId=p.id;
                Person.showPersons();

                //VideoRentalSystem.ref.updateUsersTable();
        }
        */
                Person.showPersons();
                //VideoRentalSystem.ref.updateUsersTable();
        
        }catch(Exception exc){System.out.println("Exception: "+exc);}
    }
    
    public static void loadPerson(int id)
    {
        try{
        FileInputStream fis 
            = new FileInputStream("Person_id_"+id+".txt"); 
        ObjectInputStream ois = new ObjectInputStream(fis); 
        
        Person p=(Person)ois.readObject();
        ois.close(); 
        
        System.out.println("Load person: "+p.id+" "+p.name+p.surname+p.address+p.birth_date+p.email+p.phone);
        System.out.println("p.deleted="+p.deleted);
        //new Person(10,"Albert","Einstein","1879","Germany","Ulm","albert_einstein@mail.com","123-321-123");
        
        if(p.deleted==false){
                new Person(p.id,p.name,p.surname,p.birth_date,p.address,p.city,p.email,p.phone);
                //EnterNewCustomer.maxId=10;
                EnterNewCustomer.maxId=p.id;
                Person.showPersons();

                VideoRentalSystem.ref.updateUsersTable();
        }
        
                Person.showPersons();
                VideoRentalSystem.ref.updateUsersTable();
        
        }catch(Exception exc){System.out.println("Exception: "+exc);}
    }
    
    public void calculate_unreturnedMovies()
    {
        unreturned_movies=0;
        for(Transaction t:transaction_list)
        {
            
            if(t.transaction_closed==false)
            {
                unreturned_movies=unreturned_movies+t.items.size();
            }
        }
        System.out.println(unreturned_movies);
    }
    
    public static Person getCustomer(int id)
    {
        Person ret_p=null;
        
        for(Person p:persons)
        {
            if(p.id==id)
            {
                ret_p=p;
            }
        }
        return ret_p;
    }
    
    public static void showPersons()
    {
        System.out.println("Id     Name     Surname     Birth     Address          City         Email              Phone");
        for(Person p:persons)
        {
        System.out.print(""+p.id);
        System.out.print("     "+p.name);
        System.out.print("     "+p.surname);
        System.out.print("     "+p.birth_date);
        System.out.print("     "+p.address);
        System.out.print("     "+p.city);
        System.out.print("     "+p.email);
        System.out.print("     "+p.phone);
        System.out.println("");
        }
    }
    
}
