/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;
import javax.swing.BoxLayout;
import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class StartScreen extends JFrame {
    

public BufferedImage background_image;
    
    public JButton button=new JButton("Start.");
    public JLabel start_screen_label=new JLabel();
    public JPanel panel=new JPanel(){@Override
        public void paint(Graphics g){
            super.paint(g);

            int transparency = 20; //0-255, 0 is invisible, 255 is opaque
            int colorMask = 0x00FFFFFF; //AARRGGBB
            int alphaShift = 24;

                    for(int y = 0; y < background_image.getHeight(); y++){
                        for(int x = 0; x < background_image.getWidth(); x++){
                            background_image.setRGB(x, y, (background_image.getRGB(x, y) & colorMask) | (transparency << alphaShift));
                        }
                    }

            g.drawImage(background_image, 0, 0, getWidth(), getHeight(), this);
        }
    };
    
    public JPanel panel_2=new JPanel();
    public JPanel panel_3=new JPanel();
    
    public JFrame frame=new JFrame("Mateusz Pawlowski. Video Rental System. 2024.");    
    
    StartScreen()
    {
        VideoRentalSystem.ref.frame.setVisible(false);
        
        setup_Background();
        
        ActionListener button_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_Start();
            }
        };
        
        button.addActionListener(button_action);
        
        frame = this;
        frame = new JFrame("Mateusz Pawlowski. Video Rental System. 2024.");
        panel.setPreferredSize(new Dimension(800,480));
        
        panel_2.setPreferredSize(new Dimension(800,420));
        panel_3.setPreferredSize(new Dimension(800,50));
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        
        String text="<center>Mateusz Pawlowski. Video Rental System. 2024.</center><br>email: mateuszpawlowski@gmail.com<br><br>";
        String text2="System posiada:<br>";
        String text3="<br>";
        String text4="<u>Bazę danych klientów</u> <br>- Rejestracja, edycja oraz wyszukiwanie klienta wypożyczalni wraz z podstawowymi danymi osobowymi.<br>" +
"<u>Bazę danych wypożyczeń</u> <br>- Rejestracja wszystkich wypożyczeń klientów wraz z informacjami o terminach wypożyczeń i zwrotu,<br> automatyczne naliczanie opłat oraz status wypożyczenia.<br>" +
"<u>Bazę danych Filmów</u> <br>- Dodawanie oraz edytowanie filmów dostępnych w wypożyczalni wraz z informacjami o aktorach,<br> reżyserach dacie produkcji, studiu, gatunku, cenie.<br>" +
"<u>Bazę danych Aktorów</u> <br>- Dodawanie oraz edycję aktorów i reżyserów wraz ze zdjęciem.<br>" +
"<br><u>Możliwość wyszukiwania</u> <br>- Konkretnego klienta, filmu, aktora.<br>" +
"<u>Możliwość sortowania tabel według kolumn.</u> <br>- Alfabetycznie nazwa klienta, tytuł filmu lub numerycznie rok produkcji filmu, cena wypożyczenia.<br>" +
"<u>Możliwość wypożyczenia wielu filmów podczas jednej transakcji.</u> <br>- Cena wypożyczania jest automatycznie naliczana.<br>" +
"<br><u>Możliwość zapisu systemu za pomocą przycisku Save.</u><br>";
        start_screen_label.setText("<html>"+text+text2+text3+text4+"<br></html>");
        
        panel_2.add(start_screen_label);
        panel_3.add(button);
        
        panel.add(panel_2);
        panel.add(panel_3);
        
        panel.setSize(800, 600);
        frame.setLocation(510, 365);
        frame.pack();
        //frame.show();
        frame.setVisible(true);
    }
    
    public void setup_Background()
    {
        try{
            background_image = ImageIO.read(new File("VideoRentalSystem.png"));
            //background_image = ImageIO.read(new File("blue_background.png"));
        }catch(Exception exc){}
    }
     
    public void button_Start()
    {
        frame.setVisible(false);
        VideoRentalSystem.ref.frame.setVisible(true);
    };
     
}
