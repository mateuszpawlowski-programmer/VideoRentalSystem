package videorentalsystem;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class ActorDataBase extends JFrame implements MouseListener {
    
    public static boolean created=false;
    public static ActorDataBase ref;
    
    public BufferedImage background_image;
    
    public JPanel panel=new JPanel(){@Override
        public void paint(Graphics g){
            super.paint(g);

            int transparency = 20; //0-255, 0 is invisible, 255 is opaque
            int colorMask = 0x00FFFFFF; //AARRGGBB
            int alphaShift = 24;

                    for(int y = 0; y < background_image.getHeight(); y++){
                        for(int x = 0; x < background_image.getWidth(); x++){
                            background_image.setRGB(x, y, (background_image.getRGB(x, y) & colorMask) | (transparency << alphaShift));
                        }
                    }

            g.drawImage(background_image, 0, 0, getWidth(), getHeight(), this);
        }
    };
    
    public JPanel panel2=new JPanel();
    public JPanel panel3=new JPanel();
    
    public JFrame frame=new JFrame("ActorDataBase");
    //public Thread thread;
    public JTable table=new JTable();
    public JScrollPane sp=new JScrollPane();
    
    //public JButton b5=new JButton("Rent Movie.");
    public JButton b1=new JButton("Add Actor.");
    public JButton b2=new JButton("Edit Actor.");
    public JButton b3=new JButton("Delete Actor.");
    //public JButton b20=new JButton("Actor Database.");
    public JButton b10=new JButton("Back.");
    
    //public JLabel l1=new JLabel("Title");
    //public JLabel l2=new JLabel("Director");
    public JLabel l3=new JLabel("Actor");
    
    public JTextField search_title=new JTextField(15);
    public JTextField search_director=new JTextField(15);
    public JTextField search_actor=new JTextField(15);
    public JButton b4=new JButton("Search Actor.");
    
    public JLabel l40=new JLabel("");
    public JLabel l4=new JLabel("Movie");
    
    public Actor selected_actor=null;
    public JLabel picLabel=null;
    
    public static int last_added_actor_record=36;
    
    ActorDataBase()
    {
        created=true;
        ref=this;
        
        setup_Background();
        
        //panel.add(b5);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        //panel.add(b20);
        panel.add(b10);
        
        ActionListener b1_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_AddNewActor();
            }
        };
        
        b1.addActionListener(b1_action);
        
        ActionListener b2_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_EditActor();
            }
        };
        
        b2.addActionListener(b2_action);
        
        ActionListener b3_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_DeleteActor();
            }
        };
        
        b3.addActionListener(b3_action);
        
        ActionListener b4_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_SearchMovie();
            }
        };
        
        b4.addActionListener(b4_action);
        
        ActionListener b10_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_Back();
            }
        };
        
        b10.addActionListener(b10_action);
        
        /*
        ActionListener b20_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_ActorDataBase();
            }
        };
        
        b20.addActionListener(b20_action);
        */
        
        /*
        String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
        String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
        
        table=new JTable(data,col_names);
        //DefaultTableModel dtm=(DefaultTableModel)table.getModel();
        
        
        //table=new JTable(50,5);
        
        //table.setBounds(30, 40, 200, 300);
        JScrollPane sp = new JScrollPane(table);
        
        
        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(10);
        table.getColumnModel().getColumn(2).setPreferredWidth(20);
        table.getColumnModel().getColumn(3).setPreferredWidth(30);
        table.getColumnModel().getColumn(4).setPreferredWidth(10);
        
        
        this.panel.add(sp);
        */
        
        
        
        
        frame = this;
        panel.setPreferredSize(new Dimension(820,600));
        
        frame = new JFrame("Mateusz Pawlowski. Video Rental System. 2024. ActorDataBase.");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        panel.setSize(800, 600);
        frame.setLocation(500, 300);
       
        
        /*
        new Person(1,"Jan","Kowalski","1950","Slowackiego","Warszawa","kowalski@mail.com","123456789");
        new Person(2,"Maria","Nowak","1951","Krasinskieo","Warszawa","nowakm@mail.com","789");
        new Person(3,"Jozef","Kisiel","1953","Mickiewicza","Warszawa","jk@mail.com","987");
        */
        //EnterNewCustomer.maxId=3;
        
        /*
        new Actor(0,"Harrison Ford");
        new Actor(1,"Steven Spielberg");
        new Actor(2,"Mel Gibson");
        new Actor(3,"Danny Glover");
        new Actor(4,"Richard Donner");
        new Actor(5,"Karen Allen");
        new Actor(6,"John Rhys Davies");
        new Actor(7,"Denholm Elliott");
        new Actor(8,"Alison Doody");
        new Actor(9,"Gary Busey");
        new Actor(10,"Tom Cruise");
        new Actor(11,"Jon Voight");
        new Actor(12,"Jean Reno");
        new Actor(13,"Emmanuelle Beart");
        new Actor(14,"Kristin Scott Thomas");
        new Actor(15,"Brian De Palma");
        new Actor(16,"Angelina Jolie");
        new Actor(17,"Simon West");
        new Actor(18,"Wachowskis");
        new Actor(19,"Keanu Reeves");
        new Actor(20,"Laurence Fishburne");
        new Actor(21,"Carrie Anne Moss");
                
        ArrayList<Actor> indiana_actors_list=new ArrayList<Actor>();
        indiana_actors_list.add(Actor.getActor("Harrison Ford"));
        indiana_actors_list.add(Actor.getActor("Karen Allen"));
        indiana_actors_list.add(Actor.getActor("John Rhys Davies"));
        indiana_actors_list.add(Actor.getActor("Denholm Elliott"));
        
        new Movie(1,"Indiana Jones",Actor.getActor("Steven Spielberg"),indiana_actors_list,"1981","Action","Paramount Pictures","indiana_jones_1.jpg");
        
        ArrayList<Actor> crusade_actors_list_3=new ArrayList<Actor>();
        crusade_actors_list_3.add(Actor.getActor("Harrison Ford"));
        crusade_actors_list_3.add(Actor.getActor("Alison Doody"));
        crusade_actors_list_3.add(Actor.getActor("John Rhys Davies"));
        crusade_actors_list_3.add(Actor.getActor("Denholm Elliott"));
        
        new Movie(2,"Last Crusade",Actor.getActor("Steven Spielberg"),crusade_actors_list_3,"1989","Action","Paramount Pictures","indiana_jones_3.jpg");
        
        
        ArrayList<Actor> lethal_weapon_actors_list_2=new ArrayList<Actor>();
        lethal_weapon_actors_list_2.add(Actor.getActor("Mel Gibson"));
        lethal_weapon_actors_list_2.add(Actor.getActor("Danny Glover"));
        lethal_weapon_actors_list_2.add(Actor.getActor("Gary Busey"));
        
        new Movie(3,"Lethal Weapon 1",Actor.getActor("Richard Donner"),lethal_weapon_actors_list_2,"1987","Action","Warner Bros","lethal_weapon_1.jpg");
        
        
        ArrayList<Actor> mission_impossible_actors_list=new ArrayList<Actor>();
        
        mission_impossible_actors_list.add(Actor.getActor("Tom Cruise"));
        mission_impossible_actors_list.add(Actor.getActor("Jon Voight"));
        mission_impossible_actors_list.add(Actor.getActor("Jean Reno"));
        mission_impossible_actors_list.add(Actor.getActor("Emmanuelle Beart"));
        mission_impossible_actors_list.add(Actor.getActor("Kristin Scott Thomas"));
        
        new Movie(4,"Mission Impossible",Actor.getActor("Brian De Palma"),mission_impossible_actors_list,"1996","Action","Paramount Pictures","mission_impossible.jpg");
        
        ArrayList<Actor> tr_actors_list=new ArrayList<Actor>();
        
        tr_actors_list.add(Actor.getActor("Angelina Jolie"));
        tr_actors_list.add(Actor.getActor("Jon Voight"));
        
        new Movie(5,"Tomb Raider",Actor.getActor("Simon West"),tr_actors_list,"2001","Action","Paramount Pictures","tomb_raider.png");
        
        ArrayList<Actor> matr_actors_list=new ArrayList<Actor>();
        
        matr_actors_list.add(Actor.getActor("Keanu Reeves"));
        matr_actors_list.add(Actor.getActor("Laurence Fishburne"));
        matr_actors_list.add(Actor.getActor("Carrie Anne Moss"));
        
        new Movie(6,"Matrix",Actor.getActor("Wachowskis"),matr_actors_list,"1999","Action","Warner Bros","matrix.jpg");
        */
                
        Actor.showActors();
        Movie.showMovies();
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Id");
        model.addColumn("Actor");
        
        table=new JTable(model);
       
        //table.setEnabled(false);
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,200));
        panel.add(sp);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        //panel.add(l1);panel.add(search_title);
        //panel.add(l2);panel.add(search_director);
        panel.add(l3);panel.add(search_actor);
        panel.add(b4);
        
        panel.add(panel2);
        //panel2.setLayout(new GridLayout(1,1));
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
        //panel2.setLayout(new GridLayout(1,0));
        panel2.add(l4);
        
        panel2.add(panel3);
        panel3.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        if(this.selected_actor!=null&&this.selected_actor.photo!=null){
                    try{

                        BufferedImage myPicture = ImageIO.read(new File(this.selected_actor.photo));

                        picLabel = new JLabel(new ImageIcon(myPicture.getScaledInstance(240, 240, 1)));
                        panel3.add(picLabel);
                    }catch(Exception exc){}
        }
        
        MouseListener l=new MouseListener()
        {
            @Override
            public void mouseClicked(MouseEvent me) {
                 
                 //table_selection_changed();
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                button_SearchMovie();
            }

            @Override
            public void mouseEntered(MouseEvent me) {
                
            }

            @Override
            public void mouseExited(MouseEvent me) {
                
            }
        };
        table.addMouseListener(l);
        
        
        frame.pack();
        frame.show();
        
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        for(Actor a:Actor.actors){
            
            if(a.deletedFromDatabase==false){
                model.addRow(new Object[]{a.id,a.name});
            }
            /*
            if(m.as_list.size()==1) model.addRow(new Object[]{m.id,m.title,m.director.name,m.as_list.get(0).name,m.year,m.genre,m.studio});
            if(m.as_list.size()>=2) model.addRow(new Object[]{m.id,m.title,m.director.name,m.as_list.get(0).name+", "+m.as_list.get(1).name,m.year,m.genre,m.studio});
            */
        }
        
        table.setRowSelectionInterval(0, 0);
        //button_SearchMovie();
        
        table.getColumnModel().getColumn(0).setPreferredWidth(15);
        table.getColumnModel().getColumn(1).setPreferredWidth(750);
        
        /*
        table.getColumnModel().getColumn(2).setPreferredWidth(150);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(20);
        table.getColumnModel().getColumn(6).setPreferredWidth(150);
        */
        
        /*
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(200);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);
        */
        button_SearchMovie();
        
    }
    
    public void setup_Background()
    {
        try{
            background_image = ImageIO.read(new File("VideoRentalSystem.png"));
            //background_image = ImageIO.read(new File("blue_background.png"));
        }catch(Exception exc){}
    }
    
    public void table_selection_changed()
    {
        String list_of_actors="";
        /*
        try{
            for(int i=0;i<selected_actor.as_list.size();i++)
            {
                Actor a=selected_movie.as_list.get(i);
                    if(i<selected_movie.as_list.size()-1)
                    {
                        list_of_actors=list_of_actors+a.name+", ";
                    }else list_of_actors=list_of_actors+a.name;
            }
        }catch(Exception exc){}
        */
        String sel_actor=""+this.table.getValueAt(table.getSelectedRow(), 1);
        
        String all_actor_movies="";
        
        int i=0;
        for(Movie m:Movie.movies)
        {
                
                
                if(m.director!=null&&m.director.name.equals(sel_actor))
                {
                    if(i==0) all_actor_movies=all_actor_movies+" "+m.title;
                    if(i>0) all_actor_movies=all_actor_movies+", "+m.title;
                    i++;
                }
                
                for(Actor a:m.as_list)
                {
                   if(a!=null){
                        if(a.name.equals(sel_actor))
                        {
                            if(i==0)  all_actor_movies=all_actor_movies+" "+m.title;
                            if(i>0)  all_actor_movies=all_actor_movies+", "+m.title;
                            i++;
                        }
                   }
                }
                
        }
        
        this.l4.setText("<html>Actor: "+this.table.getValueAt(table.getSelectedRow(), 1)
                +"<br>Movies: "+all_actor_movies
                +"<br><br><br><br><br><br><br><br><br><br><br><br><br><br><br>"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"</html>");
        
        
        if(this.selected_actor!=null&&this.selected_actor.photo!=null){
                try{
                    BufferedImage myPicture = ImageIO.read(new File(this.selected_actor.photo));

                    panel3.removeAll();
                    picLabel = new JLabel(new ImageIcon(myPicture.getScaledInstance(240, 240, 1)));
                    panel3.add(picLabel);
                }catch(Exception exc){}
        }
        
    }
    
    public void button_ActorDataBase()
    {
    
    }
    
    public void button_SearchMovie()
    {
        String stitle=search_title.getText();
        String sdirector=search_director.getText();
        String sactor=search_actor.getText();
        
        System.out.println("Search "+stitle+" "+sdirector+" "+sactor);
        
        int sid=(int)this.table.getValueAt(table.getSelectedRow(), 0);
        
        for(Actor a:Actor.actors)
        {
            if(a.id==sid)
            {
                selected_actor=a;
            }
        }
        
        Actor search_actor=null;
        
        for(Actor a:Actor.actors)
        {
            
            if(a.name.equals(sactor))
            {
                search_actor=a;
                selected_actor=a;
                System.out.println("Found "+sactor);break;
            }
        }
        
        
        
        
        
        
        if(search_actor!=null){
            for(int i=0;i<table.getRowCount();i++){
                int val=(int)table.getModel().getValueAt(i, 0);
                    if(search_actor.id==val)
                    {
                        table.setRowSelectionInterval(i, i);
                        table.scrollRectToVisible(new Rectangle(table.getCellRect(i, 0, true)));
                    }
            }
        }
        table_selection_changed();
        
        
        this.search_actor.setText("");
        
    }
    
    public void button_Back()
    {
        //this.frame.dispose();
        this.frame.setVisible(false);
        MovieDataBase.ref.updateMovieTable();
        MovieDataBase.ref.frame.setVisible(true);
    }
    
    public void button_DeleteActor()
    {
        int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        
        ArrayList<Actor> nlist=new ArrayList<Actor>();
        
        for(Actor a:Actor.actors)
        {
            if(a.id==rowId)
            {
                a.deletedFromDatabase=true;
            }
        }
        
        
        //MovieDataBase.ref.updateMovieTable();
        
        for(Actor a:Actor.actors)
        {
            //if(a.id!=rowId)
            //{
                nlist.add(a);
            //}
        }
        Actor.actors=nlist;
        Actor.showActors();
        updateActorTable();
        
    }
    
    public void button_EditActor()
    {
        System.out.println("edit");
        
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 0));
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 1));
        int rowId=0;
        
        try{
        rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        }catch(Exception exc){};
        
        new EditActor(this,rowId);
    }
    
    
    public void button_AddNewActor()
    {
        //new EnterNewCustomer(this);
        new AddNewActor(this);
    }
    
    public void updateActorTable()
    {
        
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Id");
        model.addColumn("Actor");
        table=new JTable(model);
        
        
        
        
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        for(Actor a:Actor.actors){
            if(a.deletedFromDatabase==false){
                model.addRow(new Object[]{a.id,a.name});
            }
        }
        
        table.setRowSelectionInterval(0, 0);
        
        table.getColumnModel().getColumn(0).setPreferredWidth(15);
        table.getColumnModel().getColumn(1).setPreferredWidth(750);
        /*
        table.getColumnModel().getColumn(2).setPreferredWidth(150);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(20);
        table.getColumnModel().getColumn(6).setPreferredWidth(150);
        */
        
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,200));
        
        panel.removeAll();
        panel2.removeAll();
        panel3.removeAll();
        
        //panel.add(b5);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        //panel.add(b20);
        panel.add(b10);
        
        panel.add(sp);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        //panel.add(l1);panel.add(search_title);
        //panel.add(l2);panel.add(search_director);
        panel.add(l3);panel.add(search_actor);
        panel.add(b4);
        
        panel.add(panel2);
        //panel2.setLayout(new GridLayout(1,1));
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
        //panel2.setLayout(new GridLayout(1,0));
        panel2.add(l4);
        
        panel2.add(panel3);
        panel3.setLayout(new FlowLayout(FlowLayout.LEFT));
        frame.pack();
        frame.show();
        
        if(this.selected_actor!=null&&this.selected_actor.photo!=null){
                    try{
                        BufferedImage myPicture = ImageIO.read(new File(this.selected_actor.photo));

                        picLabel = new JLabel(new ImageIcon(myPicture.getScaledInstance(320, 240, 1)));
                        panel3.add(picLabel);
                    }catch(Exception exc){}
        }
        
        MouseListener l=new MouseListener()
        {
            @Override
            public void mouseClicked(MouseEvent me) {
                 button_SearchMovie();
                 //table_selection_changed();
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                
            }

            @Override
            public void mouseEntered(MouseEvent me) {
                
            }

            @Override
            public void mouseExited(MouseEvent me) {
                
            }
        };
        table.addMouseListener(l);
        
        table.setRowSelectionInterval(0,0);
        
        this.search_actor.setText("");
        this.search_director.setText("");
        this.search_title.setText("");
        
        button_SearchMovie();
        
        
    }
    
    public static void main(String[] args) {
        
        
        
        //vrs.thread=new Thread(vrs);
        //vrs.thread.start();
        
        
         
         //String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
         //String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
         //vrs.table=new JTable(data_persons,col_names);
         
         
        
         
        
        
        //table=new JTable(50,5);
        
        
        /*
        vrs.table.getColumnModel().getColumn(0).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(1).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(2).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(3).setPreferredWidth(30);
        vrs.table.getColumnModel().getColumn(4).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(5).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(6).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(7).setPreferredWidth(10);
        */
        
        
        
        
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        System.out.println("123");
    }

    @Override
    public void mousePressed(MouseEvent me) {
        System.out.println("20");
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        System.out.println("30");
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        System.out.println("10");
        this.table_selection_changed();
    }

    @Override
    public void mouseExited(MouseEvent me) {
        System.out.println("11");
    }
}
