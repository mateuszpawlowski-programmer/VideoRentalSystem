package videorentalsystem;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author M
 */
public class VideoRentalSystem extends JFrame {

    public static VideoRentalSystem ref;
    
    public BufferedImage background_image;
    
    public JPanel panel=new JPanel(){@Override
        public void paint(Graphics g){
            super.paint(g);

            int transparency = 20; //0-255, 0 is invisible, 255 is opaque
            int colorMask = 0x00FFFFFF; //AARRGGBB
            int alphaShift = 24;

                    for(int y = 0; y < background_image.getHeight(); y++){
                        for(int x = 0; x < background_image.getWidth(); x++){
                            background_image.setRGB(x, y, (background_image.getRGB(x, y) & colorMask) | (transparency << alphaShift));
                        }
                    }

            g.drawImage(background_image, 0, 0, getWidth(), getHeight(), this);
        }
    };
    
    public JFrame frame=new JFrame("VideoRentalSystem");
    //public Thread thread;
    public JTable table=new JTable();
    public JScrollPane sp=new JScrollPane();
    
    public JButton b10=new JButton("Customer Rent History.");
    public JButton b5=new JButton("Movie Database.");
    public JButton b1=new JButton("Add new customer.");
    public JButton b2=new JButton("Edit customer.");
    public JButton b3=new JButton("Delete customer.");
    
    public JLabel l1=new JLabel("Name");
    public JLabel l2=new JLabel("Last Name");
    public JLabel l3=new JLabel("Email");
    
    public JTextField search_name=new JTextField(15);
    public JTextField search_last_name=new JTextField(15);
    public JTextField search_email=new JTextField(15);
    public JButton b4=new JButton("Search customer.");
    
    public static Person current_customer;
    
    public static MovieDataBase movie_data_base_ref;

    VideoRentalSystem()
    {
        ref=this;
        
        setup_Background();
        
        panel.add(b10);
        panel.add(b5);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);

        
        
        
        ActionListener b10_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_CustomerRentHistory();
            }
        };
        
        b10.addActionListener(b10_action);
        
        ActionListener b1_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_EnterNewCustomer();
            }
        };
        
        b1.addActionListener(b1_action);
        
        ActionListener b2_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_EditCustomer();
            }
        };
        
        b2.addActionListener(b2_action);
        
        ActionListener b3_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_DeleteCustomer();
            }
        };
        
        b3.addActionListener(b3_action);
        
        ActionListener b4_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_SearchCustomer();
            }
        };
        
        b4.addActionListener(b4_action);
        
        ActionListener b5_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_MovieDataBase();
            }
        };
        
        b5.addActionListener(b5_action);
        /*
        String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
        String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
        
        table=new JTable(data,col_names);
        //DefaultTableModel dtm=(DefaultTableModel)table.getModel();
        
        
        //table=new JTable(50,5);
        
        //table.setBounds(30, 40, 200, 300);
        JScrollPane sp = new JScrollPane(table);
        
        
        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(10);
        table.getColumnModel().getColumn(2).setPreferredWidth(20);
        table.getColumnModel().getColumn(3).setPreferredWidth(30);
        table.getColumnModel().getColumn(4).setPreferredWidth(10);
        
        
        this.panel.add(sp);
        */
        
        frame = this;
        frame = new JFrame("Mateusz Pawlowski. Video Rental System. 2024. Customers.");
        panel.setPreferredSize(new Dimension(820,600));
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        panel.setSize(800, 600);
        frame.setLocation(500, 300);
       
        
        
        new Person(1,"Jan","Kowalski","1950","Marszalkowska ","Warszawa","kowalski@mail.com","123-456-789");
        new Person(2,"Maria","Nowak","1980","HollyWood","LA","nowakm@mail.com","789-123-321");
        new Person(3,"John","Smith","1970","Wall Street","NY","js@mail.com","987-654-321");
        new Person(4,"Isaac","Newton","1643","United Kingdom","Woolsthrope","newton@email.com","989-898-989");
        new Person(5,"Steven","Spielberg","1946","USA","Cincinnati","steven@mail.com","987-321-123");
        new Person(6,"Thomas","Edison","1841","USA","Ohio","lightning@mail.com","111-222-333");
        new Person(7,"Bill","Gates","1955","USA","Seattle","bill_gates@microsoft.com","959-595-959");
        new Person(8,"Jeff","Bezos","1964","USA","Albuquerque","jeff@amazon.com","523-521-523");
        new Person(9,"Richard","Branson","1950","United Kingdom","London","richard@mail.com","323-321-123");
        new Person(10,"Albert","Einstein","1879","Germany","Ulm","albert_einstein@mail.com","123-321-123");
        
        EnterNewCustomer.maxId=10;
        
        Person.showPersons();
        
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public Class getColumnClass(int column) {
                switch (column) {
                    case 0:
                        return Integer.class;
                    case 1:
                        return String.class;
                    case 2:
                        return String.class;
                        case 3:
                        return String.class;
                        case 4:
                        return Integer.class;
                        case 5:
                        return String.class;
                        case 6:
                        return String.class;
                        case 7:
                        return Integer.class;
                    default:
                        return String.class;
                }
            }
        };
        
        model.addColumn("Id");
        model.addColumn("Name");
        model.addColumn("Last Name");
        //model.addColumn("Birth");
        model.addColumn("Address");
        model.addColumn("City");
        model.addColumn("Email");
        model.addColumn("Phone number");
        model.addColumn("Rented movies");
        table=new JTable(model);
        
        table.setAutoCreateRowSorter(true);
        
        //table.setEnabled(false);
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,400));
        panel.add(sp);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        panel.add(l1);panel.add(search_name);
        panel.add(l2);panel.add(search_last_name);
        panel.add(l3);panel.add(search_email);
        panel.add(b4);
        
        
        
        
        frame.pack();
        //frame.show();
        frame.setVisible(true);
        
        
        
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        for(Person p:Person.persons){
        p.calculate_unreturnedMovies();
        model.addRow(new Object[]{p.id,p.name,p.surname,p.address,p.city,p.email,p.phone,p.unreturned_movies});
        }
        table.setRowSelectionInterval(0, 0);
        
        table.getColumnModel().getColumn(0).setPreferredWidth(10);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(140);
        table.getColumnModel().getColumn(6).setPreferredWidth(80);
        
        
        
        //button_MovieDataBase();
        //MovieDataBase.ref.frame.setVisible(false);
        //VideoRentalSystem.ref.frame.setVisible(true);
        
        
        new Actor(0,"Harrison Ford").photo="Harrison_Ford.png";
        new Actor(1,"Steven Spielberg").photo="Steven_Spielberg.jpg";
        new Actor(2,"Mel Gibson").photo="Mel_Gibson.jpg";
        new Actor(3,"Danny Glover").photo="Danny_Glover.jpg";
        new Actor(4,"Richard Donner").photo="Richard_Donner.jpg";
        new Actor(5,"Karen Allen").photo="Karen_Allen.jpg";
        new Actor(6,"John Rhys Davies").photo="John_Rhys_Davies.jpg";
        new Actor(7,"Denholm Elliott").photo="Denholm_Elliott.jpg";
        new Actor(8,"Alison Doody").photo="Alison_Doody.jpg";
        new Actor(9,"Gary Busey").photo="Gary_Busey.jpg";;
        new Actor(10,"Tom Cruise").photo="Tom_Cruise.jpg";
        new Actor(11,"Jon Voight").photo="Jon_Voight.jpg";
        new Actor(12,"Jean Reno").photo="Jean_Reno.jpg";
        new Actor(13,"Emmanuelle Beart").photo="Emmanuelle_Beart.jpg";
        new Actor(14,"Kristin Scott Thomas").photo="Kristin_Scott_Thomas.jpg";
        new Actor(15,"Brian De Palma").photo="Brian_De_Palma.jpg";;
        new Actor(16,"Angelina Jolie").photo="Angelina_Jolie.jpg";
        
        
        new Actor(17,"Simon West").photo="Simon_West.jpg";;
        new Actor(18,"Wachowskis");
        new Actor(19,"Keanu Reeves").photo="Keanu_Reeves.jpg";
        new Actor(20,"Laurence Fishburne").photo="Laurence_Fishburne.jpg";;
        new Actor(21,"Carrie Anne Moss").photo="Carrie_Anne_Moss.jpg";
        
        new Actor(22,"Sylvester Stallone").photo="Sylvester_Stallone.jpg";
        new Actor(23,"Matt Damon").photo="Matt_Damon.jpg";
        new Actor(24,"Leonardo DiCaprio").photo="Leonardo_DiCaprio.jpg";
        new Actor(25,"Russel Crowe").photo="Russel_Crowe.jpg";
        new Actor(26,"Jack Nicholson").photo="Jack_Nicholson.jpg";
        new Actor(27,"Robert De Niro").photo="Robert_De_Niro.jpg";
        
        new Actor(28,"Pierce Brosnan").photo="Pierce_Brosnan.jpg";
        new Actor(29,"Izabella Scorupco").photo="Izabella_Scorupco.jpg";
        new Actor(30,"Janine Turner").photo="Janine_Turner.jpg";
        new Actor(31,"Ben Affleck").photo="Ben_Affleck.jpg";
        
        new Actor(32,"Bruce Willis").photo="Bruce_Willis.jpg";
        new Actor(33,"Mila Jovovich").photo="Mila_Jovovich.jpg";
        new Actor(34,"Vera Farmiga").photo="Vera_Farmiga.jpg";
        new Actor(35,"Arnold Schwarzenegger").photo="Arnold_Schwarzenegger.jpg";
        
        new Actor(36," ").photo="";
        
        ArrayList<Actor> indiana_actors_list=new ArrayList<Actor>();
        indiana_actors_list.add(Actor.getActor("Harrison Ford"));
        indiana_actors_list.add(Actor.getActor("Karen Allen"));
        indiana_actors_list.add(Actor.getActor("John Rhys Davies"));
        indiana_actors_list.add(Actor.getActor("Denholm Elliott"));
        
        new Movie(1,"Indiana Jones",Actor.getActor("Steven Spielberg"),indiana_actors_list,"1981","Action","Paramount Pictures","indiana_jones_1.jpg",10);
        
        ArrayList<Actor> crusade_actors_list_3=new ArrayList<Actor>();
        crusade_actors_list_3.add(Actor.getActor("Harrison Ford"));
        crusade_actors_list_3.add(Actor.getActor("Alison Doody"));
        crusade_actors_list_3.add(Actor.getActor("John Rhys Davies"));
        crusade_actors_list_3.add(Actor.getActor("Denholm Elliott"));
        
        new Movie(2,"Last Crusade",Actor.getActor("Steven Spielberg"),crusade_actors_list_3,"1989","Action","Paramount Pictures","indiana_jones_3.jpg",10);
        
        
        ArrayList<Actor> lethal_weapon_actors_list_2=new ArrayList<Actor>();
        lethal_weapon_actors_list_2.add(Actor.getActor("Mel Gibson"));
        lethal_weapon_actors_list_2.add(Actor.getActor("Danny Glover"));
        lethal_weapon_actors_list_2.add(Actor.getActor("Gary Busey"));
        
        new Movie(3,"Lethal Weapon 1",Actor.getActor("Richard Donner"),lethal_weapon_actors_list_2,"1987","Action","Warner Bros","lethal_weapon_1.jpg",8);
        
        
        ArrayList<Actor> mission_impossible_actors_list=new ArrayList<Actor>();
        
        mission_impossible_actors_list.add(Actor.getActor("Tom Cruise"));
        mission_impossible_actors_list.add(Actor.getActor("Jon Voight"));
        mission_impossible_actors_list.add(Actor.getActor("Jean Reno"));
        mission_impossible_actors_list.add(Actor.getActor("Emmanuelle Beart"));
        mission_impossible_actors_list.add(Actor.getActor("Kristin Scott Thomas"));
        
        new Movie(4,"Mission Impossible",Actor.getActor("Brian De Palma"),mission_impossible_actors_list,"1996","Action","Paramount Pictures","mission_impossible.jpg",8);
        
        ArrayList<Actor> tr_actors_list=new ArrayList<Actor>();
        
        tr_actors_list.add(Actor.getActor("Angelina Jolie"));
        tr_actors_list.add(Actor.getActor("Jon Voight"));
        
        new Movie(5,"Tomb Raider",Actor.getActor("Simon West"),tr_actors_list,"2001","Action","Paramount Pictures","tomb_raider.png",8);
        
        
        ArrayList<Actor> bourne_identity_actors_list=new ArrayList<Actor>();
        bourne_identity_actors_list.add(Actor.getActor("Matt Damon"));
        
        new Movie(6,"Bourne Identity",Actor.getActor(" "),bourne_identity_actors_list,"2002","Action","Universal Pictures","Bourne_Identity.jpg",8);
        
        
        ArrayList<Actor> matr_actors_list=new ArrayList<Actor>();
        
        matr_actors_list.add(Actor.getActor("Keanu Reeves"));
        matr_actors_list.add(Actor.getActor("Laurence Fishburne"));
        matr_actors_list.add(Actor.getActor("Carrie Anne Moss"));
        
        new Movie(7,"Matrix",Actor.getActor("Wachowskis"),matr_actors_list,"1999","Action","Warner Bros","matrix.jpg",5);
        
        ArrayList<Actor> gwh_actors_list=new ArrayList<Actor>();
        
        gwh_actors_list.add(Actor.getActor("Matt Damon"));
        gwh_actors_list.add(Actor.getActor("Ben Affleck"));
        
        new Movie(8,"Good Will Hunting",Actor.getActor(" "),gwh_actors_list,"1997","Action","Miramax Films","Good_Will_Hunting.jpg",10);
        
        ArrayList<Actor> golden_eye_actors_list=new ArrayList<Actor>();
        
        golden_eye_actors_list.add(Actor.getActor("Pierce Brosnan"));
        golden_eye_actors_list.add(Actor.getActor("Izabella Scorupco"));
        
        new Movie(9,"Golden Eye",Actor.getActor(" "),golden_eye_actors_list,"1995","Action","MGM","GoldenEye.jpg",10);
        
        ArrayList<Actor> ronin_actors_list=new ArrayList<Actor>();
        
        ronin_actors_list.add(Actor.getActor("Robert De Niro"));
        ronin_actors_list.add(Actor.getActor("Jean Reno"));
        
        new Movie(10,"Ronin",Actor.getActor(" "),ronin_actors_list,"1998","Action","MGM","Ronin.jpg",5);
        
        ArrayList<Actor> fifth_element_actors_list=new ArrayList<Actor>();
        
        fifth_element_actors_list.add(Actor.getActor("Bruce Willis"));
        fifth_element_actors_list.add(Actor.getActor("Mila Jovovich"));
        
        new Movie(11,"Fifth Element",Actor.getActor(" "),fifth_element_actors_list,"1997","Action","Buena Vista Interational","Fifth_Element.jpg",10);
        
        
        ArrayList<Actor> terminator_1_actors_list=new ArrayList<Actor>();
        terminator_1_actors_list.add(Actor.getActor("Arnold Schwarzenegger"));
        
        new Movie(12,"Terminator 1",Actor.getActor(" "),terminator_1_actors_list,"1984","Action","Orion Pictures","Terminator_1.jpg",5);
        
        
        ArrayList<Actor> terminator_2_actors_list=new ArrayList<Actor>();
        terminator_2_actors_list.add(Actor.getActor("Arnold Schwarzenegger"));
        
        new Movie(13,"Terminator 2",Actor.getActor(" "),terminator_1_actors_list,"1991","Action","Tri-Star Pictures","Terminator_2.jpg",10);
        
        
        ArrayList<Actor> red_heat_actors_list=new ArrayList<Actor>();
        red_heat_actors_list.add(Actor.getActor("Arnold Schwarzenegger"));
        
        new Movie(14,"Red Heat",Actor.getActor(" "),red_heat_actors_list,"1988","Action","Tri-Star Pictures","Red_Heat.jpg",10);
        
        
        ArrayList<Actor> die_hard_actors_list=new ArrayList<Actor>();
        die_hard_actors_list.add(Actor.getActor("Bruce Willis"));
        
        new Movie(15,"Die Hard",Actor.getActor(" "),die_hard_actors_list,"1988","Action","20 Century FOX","Die_Hard.jpg",10);
        
        
        ArrayList<Actor> cliff_hanger_actors_list=new ArrayList<Actor>();
        cliff_hanger_actors_list.add(Actor.getActor("Sylvester Stallone"));
        cliff_hanger_actors_list.add(Actor.getActor("Janine Turner"));
        
        new Movie(16,"Cliff Hanger",Actor.getActor(" "),cliff_hanger_actors_list,"1993","Action","Tri-Star Pictures","Cliff_Hanger.jpg",10);
        
        
        ArrayList<Actor> gladiator_actors_list=new ArrayList<Actor>();
        gladiator_actors_list.add(Actor.getActor("Russel Crowe"));
        
        new Movie(17,"Gladiator",Actor.getActor(" "),gladiator_actors_list,"2000","Action","Universal Pictures","Gladiator.jpg",5);
        
        
        ArrayList<Actor> departed_actors_list=new ArrayList<Actor>();
        departed_actors_list.add(Actor.getActor("Matt Damon"));
        departed_actors_list.add(Actor.getActor("Vera Farmiga"));
        departed_actors_list.add(Actor.getActor("Jack Nicholson"));
        
        new Movie(18,"Departed",Actor.getActor(" "),departed_actors_list,"2006","Action","Warner Bros","Departed.jpg",1);
        
        
        
        //demo transaction
        Transaction t1=new Transaction(Person.persons.get(0));
        t1.addMovieToCart(Movie.movies.get(0));
        t1.addMovieToCart(Movie.movies.get(1));
        t1.addMovieToCart(Movie.movies.get(10));
        t1.saveTransation_for_demo_1();
        t1.calculateCost();
        t1.calculateDateString();
        Person.persons.get(0).transaction_list.add(t1);
        
        Transaction t2=new Transaction(Person.persons.get(0));
        t2.addMovieToCart(Movie.movies.get(5));
        t2.addMovieToCart(Movie.movies.get(6));
        t2.addMovieToCart(Movie.movies.get(7));
        t2.saveTransation_for_demo_2();
        t2.calculateCost();
        t2.transaction_closed=true;
        t2.calculateCost();
        t2.calculateDateString();
        Person.persons.get(0).transaction_list.add(t2);
        
        Transaction t3=new Transaction(Person.persons.get(0));
        t3.addMovieToCart(Movie.movies.get(4));
        t3.saveTransation();
        t3.calculateCost();
        t3.transaction_closed=true;
        t3.calculateCost();
        t3.calculateDateString();
        Person.persons.get(0).transaction_list.add(t3);
        
        
        Transaction t4=new Transaction(Person.persons.get(1));
        t4.addMovieToCart(Movie.movies.get(4));
        t4.saveTransation_for_demo_1();
        t4.calculateCost();
        t4.calculateDateString();
        Person.persons.get(1).transaction_list.add(t4);
        
        
       
        
        this.updateUsersTable();
        
        
         
    }
    
    public void setup_Background()
    {
        try{
            background_image = ImageIO.read(new File("VideoRentalSystem.png"));
            //background_image = ImageIO.read(new File("blue_background.png"));
        }catch(Exception exc){}
    }
     
    public void button_CustomerRentHistory()
    {
        int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        System.out.println(""+rowId+" "+table.getValueAt(table.getSelectedRow(),1));
        
        this.current_customer=Person.getCustomer(rowId);
            
        new CustomerRentHistory();
    }
    
    public void button_MovieDataBase()
    {
        //new MovieDataBase();
            
            int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
            System.out.println(""+rowId+" "+table.getValueAt(table.getSelectedRow(),1));
            
            this.current_customer=Person.getCustomer(rowId);
            
            
        if(MovieDataBase.created==false)
        {
            current_customer.current_transaction=new Transaction(current_customer);
            
            this.frame.setVisible(false);
            movie_data_base_ref=new MovieDataBase();
        }
        
        if(MovieDataBase.created==true)
        {
            current_customer.current_transaction=new Transaction(current_customer);
            
            this.frame.setVisible(false);
            MovieDataBase.ref.frame.setVisible(true);
            movie_data_base_ref.button_SearchMovie();
            
        }
    }
    
    public void button_SearchCustomer()
    {
        String sname=search_name.getText();
        String slname=search_last_name.getText();
        String semail=search_email.getText();
        
        System.out.println("Search "+sname+" "+slname+" "+semail);
        
        Person search_person=null;
        for(Person p:Person.persons)
        {
            if(p.name.equals(sname)&&p.surname.equals(slname)&&p.email.equals(semail))
            {
                search_person=p;
                System.out.println("Found "+sname+" "+slname+" "+semail);
            }
            if(p.name.equals(sname)&&p.surname.equals(slname))
            {
                search_person=p;
                search_email.setText("");
                System.out.println("Found "+sname+" "+slname);
            }
            else if(p.email.equals(semail))
            {
                search_person=p;
                search_name.setText("");
                search_last_name.setText("");
                
                System.out.println("Found "+semail);
            }
        }
        
        
        if(search_person!=null){
            for(int i=0;i<table.getRowCount();i++){
                //int val=(int)table.getModel().getValueAt(i, 0);
                int val=(int)table.getValueAt(i, 0);
                
                    if(search_person.id==val)
                    {
                        //table.setRowSelectionInterval(i,i);
                        table.getSelectionModel().setSelectionInterval(i, i);
                        
                        table.scrollRectToVisible(new Rectangle(table.getCellRect(i, 0, true)));
                        
                    }
            }
        }
        
        search_name.setText("");
        search_last_name.setText("");
        search_email.setText("");
    }
    
    public void button_DeleteCustomer()
    {
        int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        
        ArrayList<Person> nlist=new ArrayList<Person>();
        
        for(Person p:Person.persons)
        {
            if(p.id!=rowId)
            {
                nlist.add(p);
            }
        }
        Person.persons=nlist;
        Person.showPersons();
        updateUsersTable();
    }
    
    public void button_EditCustomer()
    {
        System.out.println("edit");
        
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 0));
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 1));
        int rowId=0;
        
        try{
        rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        }catch(Exception exc){};
        
        new EditCustomer(this,rowId);
    }
    
    
    public void button_EnterNewCustomer()
    {
        new EnterNewCustomer(this);
    }
    
    public void updateUsersTable()
    {
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public Class getColumnClass(int column) {
                switch (column) {
                    case 0:
                        return Integer.class;
                    case 1:
                        return String.class;
                    case 2:
                        return String.class;
                        case 3:
                        return String.class;
                        case 4:
                        return Integer.class;
                        case 5:
                        return String.class;
                        case 6:
                        return String.class;
                        case 7:
                        return Integer.class;
                    default:
                        return String.class;
                }
            }
        };
        
        model.addColumn("Id");
        model.addColumn("Name");
        model.addColumn("Last Name");
        //model.addColumn("Birth Date");
        model.addColumn("Address");
        model.addColumn("City");
        model.addColumn("Email");
        model.addColumn("Phone number");
        model.addColumn("Rented movies");
        
        this.table=new JTable(model);
        
        table.setAutoCreateRowSorter(true);
        
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        for(Person p:Person.persons){
        p.calculate_unreturnedMovies();
        model.addRow(new Object[]{p.id,p.name,p.surname,p.address,p.city,p.email,p.phone,p.unreturned_movies});
        }
        
        table.setRowSelectionInterval(0, 0);
        
        table.getColumnModel().getColumn(0).setPreferredWidth(10);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(140);
        table.getColumnModel().getColumn(6).setPreferredWidth(80);
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,400));
        
        panel.removeAll();
        
        panel.add(b10);
        panel.add(b5);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        
        panel.add(sp);
        
        panel.add(l1);panel.add(search_name);
        panel.add(l2);panel.add(search_last_name);
        panel.add(l3);panel.add(search_email);
        panel.add(b4);
        
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        
        
        frame.pack();
        //frame.show();
        frame.setVisible(true);
        
        
        
        /*
        frame.setUndecorated(true);
        frame.getContentPane().setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
        frame.setBackground(new Color(1.0f,1.0f,1.0f,0.0f));
        */
       
        
        
        Person.showPersons();
    }
     
    public static void main(String[] args) {
        VideoRentalSystem vrs=new VideoRentalSystem();
        
        
        //vrs.thread=new Thread(vrs);
        
        
        
         
         //String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
         //String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
         //vrs.table=new JTable(data_persons,col_names);
         
         
        
         
        
        
        //table=new JTable(50,5);
        
        
        /*
        vrs.table.getColumnModel().getColumn(0).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(1).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(2).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(3).setPreferredWidth(30);
        vrs.table.getColumnModel().getColumn(4).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(5).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(6).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(7).setPreferredWidth(10);
        */
    }
}
