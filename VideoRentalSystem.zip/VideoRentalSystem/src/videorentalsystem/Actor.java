/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;


//String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};

public class Actor implements Serializable{
  
    private static final long SerialVersionUID = 10l;
    
    public Integer id;
    public String name;
    
    public String photo;
    
    public boolean deletedFromDatabase;
    
    public static ArrayList<Actor> actors=new ArrayList<Actor>();
    
    public static int nr=0;
    
    Actor(Integer id,String name)
    {
        this.id=id;
        this.name=name;
        
        boolean exists=false;
        
        for(Actor a:actors){
            if(a.id==id) exists=true;
        }
        
        if(exists==false) actors.add(this);
        
    }
    
    public void changeName(String nname)
    {
        this.name=nname;
    }
    
    public static Actor getActorByNumber(Integer i)
    {
        Actor actr=null;
        
        for(Actor a:Actor.actors)
        {
            if(a.id.equals(i)){actr=a;}
        }
        return actr;
    }
    
public static void saveAll_Actors_for_Serializable()
{
    for(Actor a:Actor.actors)
    {
        a.saveActor_for_Serializable();
    }
}

public void saveActor_for_Serializable()
{
        try{
            FileOutputStream fos 
                = new FileOutputStream("Actor_id_"+this.id+".txt"); 
            ObjectOutputStream oos 
                = new ObjectOutputStream(fos); 
            oos.writeObject(this); 
            oos.close(); 
            System.out.println("Save actor: "+this.id+" "+this.name+" deleted"+this.deletedFromDatabase);
        }catch(Exception exc){System.out.println("Exception: "+exc);}
}

public static void loadAllActors()
{
    for(int nr=0;nr<1000;nr++){
                    try{
                        FileInputStream fis 
                            = new FileInputStream("Actor_id_"+nr+".txt"); 
                        ObjectInputStream ois = new ObjectInputStream(fis); 

                        //System.out.println("number "+nr);
                        Actor.loadActor(nr);
                    }catch(Exception exc)
                    {
                        //System.out.println("error "+exc);
                    }
        }
}

public static void loadActor(int id)
{
        try{
        FileInputStream fis 
            = new FileInputStream("Actor_id_"+id+".txt"); 
        ObjectInputStream ois = new ObjectInputStream(fis); 
        
        Actor a=(Actor)ois.readObject();
        
        if(a.deletedFromDatabase==false){
            Actor.actors.add(a);
        }
        
        ois.close(); 
        
        System.out.println("Load actor: "+a.id+" "+a.name+" deleted"+a.deletedFromDatabase);
                //EnterNewCustomer.maxId=10;
        }catch(Exception exc){System.out.println("Load actor Exception: "+exc);}
}

    public String toString()
    {
        return this.name;
    }
    
    public static void showActors()
    {
        System.out.println("Id     Name");
        for(Actor a:actors)
        {
        System.out.print(""+a.id);
        System.out.print("     "+a.name);
        System.out.println("");
        }
    }
    
    public static Integer getActorIdByName(String name)
    {
        for(Actor a:actors)
        {
            if(a.name.equals(name))
            {
                return a.id;
            }
        }
        return 0;
    }
    
    public static Actor getActor(String name)
    {
        
        for(Actor a:actors)
        {
            if(a.name.equals(name))
            {
                return a;
            }
        }
        return null;
    }
    
}
