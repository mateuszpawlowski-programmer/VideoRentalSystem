/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.util.ArrayList;
import java.util.Date;


//String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};

public class Actor {
  
    public Integer id;
    public String name;
    
    public String photo;
    
    public boolean deletedFromDatabase=false;
    
    public static ArrayList<Actor> actors=new ArrayList<Actor>();
    
    public static int nr=0;
    
    Actor(Integer id,String name)
    {
        this.id=id;
        this.name=name;
        
        boolean exists=false;
        
        for(Actor a:actors){
            if(a.id==id) exists=true;
        }
        
        if(exists==false) actors.add(this);
        
    }
    
    public String toString()
    {
        return this.name;
    }
    
    public static void showActors()
    {
        System.out.println("Id     Name");
        for(Actor a:actors)
        {
        System.out.print(""+a.id);
        System.out.print("     "+a.name);
        System.out.println("");
        }
    }
    
    public static Actor getActor(String name)
    {
        
        for(Actor a:actors)
        {
            if(a.name.equals(name))
            {
                return a;
            }
        }
        return null;
    }
    
}
