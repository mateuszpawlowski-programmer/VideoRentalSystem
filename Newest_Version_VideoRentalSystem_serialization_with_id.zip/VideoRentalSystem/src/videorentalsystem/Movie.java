/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;


//String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};

public class Movie implements Serializable{
  
    private static final long SerialVersionUID = 10l;
    
    public Integer id;
    public String title;
    
    public Actor director;
    
    public Integer director_id;
    
    transient public ArrayList<Actor> as_list=new ArrayList<Actor>();
    public ArrayList<Integer> as_list_numbers=new ArrayList<Integer>();
    
    public String year;
    public String genre;
    public String studio;
    
    public String poster_path;
        
    public int quantity=10;
    public Double price=10.0;
    
    public boolean deleted=false;
    
    public static ArrayList<Movie> movies=new ArrayList<Movie>();
    
    Movie(Integer id,String title,Actor director,String year,String genre,String studio,String poster_path,double price)
    {
        this.id=id;
        this.title=title;
        this.director=director;
        
        this.year=year;
        this.genre=genre;
        this.studio=studio;
        
        this.poster_path=poster_path;
        this.price=price;
        
        boolean exists=false;
        
        for(Movie m:movies){
            if(m.id==id) exists=true;
        }
        
        if(exists==false) movies.add(this);
        
    }
    
    public void addActorByNumber(Integer i)
    {
        this.as_list_numbers.add(i);
    }
    
    public void addDirectorByNumber(Integer i)
    {
        this.director_id=i;
    }
    
    public void recreateActorList()
    {
        as_list=new ArrayList<Actor>();
        for(Integer i:as_list_numbers)
        {
            Actor actr=Actor.getActorByNumber(i);
            as_list.add(actr);
        }
        
        director=Actor.getActorByNumber(director_id);
    }
    
    public void addActor(Actor a)
    {
        this.as_list.add(a);
    }
    
    public String getList()
    {
        String list="";
        for(Actor a:this.as_list)
        {
           if(a!=null) list=list+" "+a.name;
        }
        return list;
    }
    
public static void saveAll_Movies_for_Serializable()
{
    for(Movie m:Movie.movies)
    {
        m.saveMovie_for_Serializable();
    }
}

public void correct_actors_list()
{
    ArrayList<Actor> n_as_list=new ArrayList<Actor>();
    
    for(Actor a:this.as_list)
    {
        if(a.deletedFromDatabase==false)
        {
            n_as_list.add(a);
        }
    }
    
    this.as_list=n_as_list;
}

public void saveMovie_for_Serializable()
{
        
        
        try{
            FileOutputStream fos 
                = new FileOutputStream("Movie_id_"+this.id+".txt"); 
            ObjectOutputStream oos 
                = new ObjectOutputStream(fos); 
            oos.writeObject(this); 
            oos.close(); 
            System.out.println("Save movie: "+this.id+" "+this.title+" deleted "+this.deleted);
        }catch(Exception exc){System.out.println("Exception: "+exc);}
}

public static void loadAllMovies()
{
    for(int nr=1;nr<100;nr++){
                    try{
                        FileInputStream fis 
                            = new FileInputStream("Movie_id_"+nr+".txt"); 
                        ObjectInputStream ois = new ObjectInputStream(fis); 

                        //System.out.println("number "+nr);
                        Movie.loadMovie(nr);

                    }catch(Exception exc)
                    {
                        //System.out.println("error "+exc);
                    }
        }
}

public static void loadMovie(int id)
{
        try{
        FileInputStream fis 
            = new FileInputStream("Movie_id_"+id+".txt"); 
        ObjectInputStream ois = new ObjectInputStream(fis); 
        
        Movie m=(Movie)ois.readObject();
        
        //if(m.deleted==false){
            Movie.movies.add(m);
        //}
        
        ois.close(); 
        
        System.out.println("Load movie: "+m.id+" "+m.title+" deleted "+m.deleted);
                //EnterNewCustomer.maxId=10;
        }catch(Exception exc){System.out.println("Load movie Exception: "+exc);}
}

    public static Movie getMovieById(Integer id)
    {
        for(Movie m:movies)
        {
            if(m.id.equals(id)) return m;
        }
        return null;
    }
    
    public static Movie getMovieByTitle(String title)
    {
        for(Movie m:movies)
        {
            if(m.title.equals(title)) {return m;};
        }
        return null;
    }
    
    public static void showMovies()
    {
        System.out.println("Id     Title     Director     Actors     Year          Genre         Studio");
        for(Movie m:movies)
        {
        System.out.print(""+m.id);
        System.out.print("     "+m.title);
        
        if(m.director!=null) System.out.print("     "+m.director.name);
            
        
            System.out.print("     "+m.getList());
        
        
        System.out.print("     "+m.year);
        System.out.print("     "+m.genre);
        System.out.print("     "+m.studio);
        System.out.println("");
        }
    }
    
}
