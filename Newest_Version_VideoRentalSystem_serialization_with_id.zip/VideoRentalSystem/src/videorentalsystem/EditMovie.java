/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;


import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class EditMovie extends JFrame {
    
    public JPanel panel=new JPanel();
    
    public JPanel panel_title=new JPanel();
    
    public JPanel panel_1=new JPanel();
    public JPanel panel_2=new JPanel();
    public JPanel panel_3=new JPanel();
    public JPanel panel_4=new JPanel();
    public JPanel panel_5=new JPanel();
    public JPanel panel_6=new JPanel();
    public JPanel panel_7=new JPanel();
    public JPanel panel_8=new JPanel();
    public JPanel panel_9=new JPanel();
    
    public JButton button_enter=new JButton("Update");
    public JButton button_cancel=new JButton("Cancel");
    
    public JFrame frame=new JFrame("Edit Movie.");
    public JLabel label1=new JLabel("Edit Movie");
    
    public JLabel elabel=new JLabel("");
    public JLabel elabel2=new JLabel(" ");
    public JLabel elabel3=new JLabel("");
    public JLabel elabel4=new JLabel("");
    public JLabel elabel5=new JLabel("");
    
    public JTextField title=new JTextField(20);
    public JTextField director=new JTextField(20);
    public JTextField actors=new JTextField(20);
    public JTextField year=new JTextField(20);
    public JTextField genre=new JTextField(20);
    public JTextField studio=new JTextField(20);
    public JTextField poster=new JTextField(20);
    
    public JTextField price=new JTextField(20);
    
    public JLabel l1=new JLabel("Title");
    public JLabel l2=new JLabel("Director");
    public JLabel l3=new JLabel("Actors");
    public JLabel l4=new JLabel("Year");
    public JLabel l5=new JLabel("Genre");
    public JLabel l6=new JLabel("Studio");
    public JLabel l7=new JLabel("Poster");
    
    public JLabel l8=new JLabel("Price");

    public JList jl0=new JList();
    public JList jl1=new JList();
    
    public JScrollPane scrollableList0;
    public JScrollPane scrollableList1;
    
    public MovieDataBase sys_ref;
    
    public Movie movie_to_update=null;
    
    
    
    EditMovie(MovieDataBase mdbr,int row)
    {
        sys_ref=mdbr;
        
        //frame.setPreferredSize(new Dimension(500,300));
        panel.setPreferredSize(new Dimension(500,380));
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(700, 450);
        
        
        
        
        //panel.setLayout(new GridLayout(8,0));
        
        panel_1.setLayout(new GridLayout(1,0));
        
        jl0=new JList(Actor.actors.toArray());
        jl0.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        scrollableList0 = new JScrollPane(jl0);
        panel_2.add(l2);panel_2.add(scrollableList0);
        
        //panel_2.setLayout(new GridLayout(1,0));
        //panel_3.setLayout(new GridLayout(1,0));
        jl1=new JList(Actor.actors.toArray());
        scrollableList1 = new JScrollPane(jl1);
        panel_3.add(l3);panel_3.add(scrollableList1);
        
        panel_4.setLayout(new GridLayout(1,0));
        panel_5.setLayout(new GridLayout(1,0));
        panel_6.setLayout(new GridLayout(1,0));
        panel_7.setLayout(new GridLayout(1,0));
        panel_8.setLayout(new GridLayout(1,0));
        panel_9.setLayout(new GridLayout(0,6));
                
        panel_title.add(label1);
        panel_1.add(l1);panel_1.add(title);
        //panel_2.add(l2);panel_2.add(director);
        //panel_3.add(l3);panel_3.add(actors);
        panel_4.add(l4);panel_4.add(year);
        panel_5.add(l5);panel_5.add(genre);
        panel_6.add(l6);panel_6.add(studio);
        panel_7.add(l7);panel_7.add(poster);
        panel_8.add(l8);panel_8.add(price);
        
        movie_to_update=null;
        for(Movie m:Movie.movies)
        {
            if(m.id==row) movie_to_update=m;
        }
        
        title.setText(""+movie_to_update.title);
        //director.setText(""+movie_to_update.director.name);
        //actors.setText(""+movie_to_update.as_list.get(0).name);
        year.setText(""+movie_to_update.year);
        genre.setText(""+movie_to_update.genre);
        studio.setText(""+movie_to_update.studio);
        poster.setText(""+movie_to_update.poster_path);
        price.setText(""+movie_to_update.price);
        
        jl0.setSelectedIndex(movie_to_update.director.id);
        
        
        int t[]=new int[movie_to_update.as_list.size()];
        
        int i=0;
        for(Actor a:movie_to_update.as_list)
        {
            t[i]=(int)a.id;
            i++;
        }
        
        
        jl1.setSelectedIndices(t);
        
        //frame.getContentPane().add(panel);
        frame.add(panel);
        
        panel.add(panel_title);
        panel.add(panel_1);
        panel.add(panel_2);
        panel.add(panel_3);
        panel.add(panel_4);
        panel.add(panel_5);
        panel.add(panel_6);
        panel.add(panel_7);
        panel.add(panel_8);
        
        panel_9.add(elabel);
        panel_9.add(elabel2);
        panel_9.add(elabel3);
        panel_9.add(elabel4);
        
        
        panel_9.add(button_enter);
        panel_9.add(button_cancel);
        
        panel.add(panel_8);
        panel.add(panel_9);
        
        ActionListener b_enter=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_enter();
            }
        };
        
        this.button_enter.addActionListener(b_enter);
        
        
        ActionListener b_cancel=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_cancel();
            }
        };
        
        this.button_cancel.addActionListener(b_cancel);
        
        frame.pack();
        frame.show();
    }
    
    public void button_enter()
    {
        //maxId=maxId+1;
        //new Person(maxId,this.name.getText(),this.surname.getText(),this.birth.getText(),this.address.getText(),this.city.getText(),this.email.getText(),this.phone.getText());
        //ArrayList<Actor> list=new ArrayList<Actor>();
        //list.add(Actor.getActor("Angelina Jolie"));
        //list.add(Actor.getActor(actors.getText()));
        
        
        
        String director_name=""+jl0.getSelectedValue();
        
        System.out.println(""+jl0.getSelectedValue());
        System.out.println(""+jl1.getSelectedValuesList());
        
        ArrayList<Actor> movie_actors_list=new ArrayList<Actor>();
        
        movie_to_update.as_list.clear();
        movie_to_update.as_list_numbers.clear();
        
        for(int i=0;i<jl1.getSelectedValuesList().size();i++)
        {
            String actor_name=""+jl1.getSelectedValuesList().get(i);
            //movie_actors_list.add(Actor.getActor(actor_name));
            movie_to_update.as_list.add(Actor.getActor(actor_name));
            movie_to_update.as_list_numbers.add(Actor.getActor(actor_name).id);
        }
        
        //new Movie(maxId,"Tomb Raider 2",Actor.getActor("Angelina Jolie"),list,"2024","Action","Paramount Pictures","tomb_raider.png");
        //new Movie(maxId,title.getText(),Actor.getActor(director.getText()),list,year.getText(),genre.getText(),studio.getText(),poster.getText());
        
        //sys_ref.last_added_movie_record=maxId-1;
        movie_to_update.title=title.getText();
        
        //movie_to_update.director.name=director_name;
        //movie_to_update.director.name="Harrison Ford";
        
        movie_to_update.director=Actor.getActor(director_name);
        movie_to_update.director_id=Actor.getActor(director_name).id;
        //movie_to_update.as_list=movie_actors_list;
        
        //actors.setText(""+movie_to_update.as_list.get(0).name);
        movie_to_update.year=year.getText();
        movie_to_update.genre=genre.getText();
        movie_to_update.studio=studio.getText();
        movie_to_update.poster_path=poster.getText();
        movie_to_update.price=Double.parseDouble(price.getText());
        
        
        sys_ref.updateMovieTable();
        this.frame.dispose();
    }
    
    public void button_cancel()
    {
        this.frame.dispose();
    }
}
