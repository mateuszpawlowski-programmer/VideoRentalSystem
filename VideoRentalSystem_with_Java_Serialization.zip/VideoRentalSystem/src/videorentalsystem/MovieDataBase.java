package videorentalsystem;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.GridLayout;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

public class MovieDataBase extends JFrame implements MouseListener {
    
    public static boolean created=false;
    public static MovieDataBase ref;
    
    public BufferedImage background_image;
    
    public JPanel panel=new JPanel(){@Override
        public void paint(Graphics g){
            super.paint(g);

            int transparency = 20; //0-255, 0 is invisible, 255 is opaque
            int colorMask = 0x00FFFFFF; //AARRGGBB
            int alphaShift = 24;

                    for(int y = 0; y < background_image.getHeight(); y++){
                        for(int x = 0; x < background_image.getWidth(); x++){
                            background_image.setRGB(x, y, (background_image.getRGB(x, y) & colorMask) | (transparency << alphaShift));
                        }
                    }

            g.drawImage(background_image, 0, 0, getWidth(), getHeight(), this);
        }
    };
    
    public JPanel panel2=new JPanel();
    public JPanel panel3=new JPanel();
    
    public JFrame frame=new JFrame("MovieDataBase");
    //public Thread thread;
    public JTable table=new JTable();
    public JScrollPane sp=new JScrollPane();
    
    public JButton b5=new JButton("Add to Cart.");
    public JButton b1=new JButton("Add Movie.");
    public JButton b2=new JButton("Edit Movie.");
    public JButton b3=new JButton("Delete Movie.");
    public JButton b20=new JButton("Actor Database.");
    public JButton b10=new JButton("Back.");
    
    public JButton b30=new JButton("Make order.");
    
    public JLabel l1=new JLabel("Title");
    public JLabel l2=new JLabel("Director");
    public JLabel l3=new JLabel("Actor");
    
    public JTextField search_title=new JTextField(15);
    public JTextField search_director=new JTextField(15);
    public JTextField search_actor=new JTextField(15);
    public JButton b4=new JButton("Search Movie.");
    
    public JLabel l40=new JLabel("");
    public JLabel l4=new JLabel("Movie");
    
    public Movie selected_movie=null;
    public JLabel picLabel=null;
    
    public static int last_added_movie_record=18;
    
    MovieDataBase()
    {
        created=true;
        ref=this;
        
        setup_Background();
        
        panel.add(b5);
        panel.add(b30);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(b20);
        panel.add(b10);
        
        ActionListener b30_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_makeOrder();
            }
        };
        
        b30.addActionListener(b30_action);
        
        
        ActionListener b5_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_RentMovie();
            }
        };
        
        b5.addActionListener(b5_action);
        
        ActionListener b1_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_AddNewMovie();
            }
        };
        
        b1.addActionListener(b1_action);
        
        ActionListener b2_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_EditMovie();
            }
        };
        
        b2.addActionListener(b2_action);
        
        ActionListener b3_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_DeleteMovie();
            }
        };
        
        b3.addActionListener(b3_action);
        
        ActionListener b4_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_SearchMovie();
            }
        };
        
        b4.addActionListener(b4_action);
        
        ActionListener b10_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_Back();
            }
        };
        
        b10.addActionListener(b10_action);
        
        ActionListener b20_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_ActorDataBase();
            }
        };
        
        b20.addActionListener(b20_action);
        /*
        String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
        String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
        
        table=new JTable(data,col_names);
        //DefaultTableModel dtm=(DefaultTableModel)table.getModel();
        
        
        //table=new JTable(50,5);
        
        //table.setBounds(30, 40, 200, 300);
        JScrollPane sp = new JScrollPane(table);
        
        
        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(10);
        table.getColumnModel().getColumn(2).setPreferredWidth(20);
        table.getColumnModel().getColumn(3).setPreferredWidth(30);
        table.getColumnModel().getColumn(4).setPreferredWidth(10);
        
        
        this.panel.add(sp);
        */
        
        
        
        
        frame = this;
        
        panel.setPreferredSize(new Dimension(820,600));
        
        frame = new JFrame("Mateusz Pawlowski. Video Rental System. 2024. MovieDataBase.");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        panel.setSize(800, 600);
        frame.setLocation(500, 300);
       
        
        /*
        new Person(1,"Jan","Kowalski","1950","Slowackiego","Warszawa","kowalski@mail.com","123456789");
        new Person(2,"Maria","Nowak","1951","Krasinskieo","Warszawa","nowakm@mail.com","789");
        new Person(3,"Jozef","Kisiel","1953","Mickiewicza","Warszawa","jk@mail.com","987");
        */
        //EnterNewCustomer.maxId=3;
        
        
        
        
        Actor.showActors();
        Movie.showMovies();
        
        DefaultTableModel model = new DefaultTableModel(){
            @Override
            public Class getColumnClass(int column) {
                switch (column) {
                    case 0:
                        return Integer.class;
                    case 1:
                        return String.class;
                    case 2:
                        return String.class;
                        case 3:
                        return String.class;
                        case 4:
                        return Integer.class;
                        case 5:
                        return String.class;
                        case 6:
                        return String.class;
                        case 7:
                        return Integer.class;
                    default:
                        return String.class;
                }
            }
        };
        
        model.addColumn("Id");
        model.addColumn("Title");
        model.addColumn("Director");
        model.addColumn("Actors");
        model.addColumn("Year");
        model.addColumn("Genre");
        model.addColumn("Studio");
        model.addColumn("Price");
        
        table=new JTable(model);
        
        table.setAutoCreateRowSorter(true);
        
        //table.setEnabled(false);
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,200));
        panel.add(sp);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        panel.add(l1);panel.add(search_title);
        panel.add(l2);panel.add(search_director);
        panel.add(l3);panel.add(search_actor);
        panel.add(b4);
        
        panel.add(panel2);
        //panel2.setLayout(new GridLayout(1,1));
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
        //panel2.setLayout(new GridLayout(1,0));
        panel2.add(l4);
        
        panel2.add(panel3);
        panel3.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        try{
            //BufferedImage myPicture = ImageIO.read(new File("indiana_jones_1.jpg"));
            BufferedImage myPicture = ImageIO.read(new File(this.selected_movie.poster_path));
            
            picLabel = new JLabel(new ImageIcon(myPicture.getScaledInstance(69*3, 100*3, 1)));
            panel3.add(picLabel);
        }catch(Exception exc){}
        
        
        
        MouseListener l=new MouseListener()
        {
            @Override
            public void mouseClicked(MouseEvent me) {
                 
                 //table_selection_changed();
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                button_SearchMovie();
            }

            @Override
            public void mouseEntered(MouseEvent me) {
                
            }

            @Override
            public void mouseExited(MouseEvent me) {
                
            }
        };
        table.addMouseListener(l);
        
        
        frame.pack();
        frame.show();
        
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        for(Movie m:Movie.movies){
            
            //System.out.println(""+m.as_list.get(0).name);
                
            if(m.deleted==false)
            {
                model.addRow(new Object[]{new Integer(m.id),m.title,m.director.name,m.getList(),m.year,m.genre,m.studio,m.price});
            }
            /*
            if(m.as_list.size()==1) model.addRow(new Object[]{m.id,m.title,m.director.name,m.as_list.get(0).name,m.year,m.genre,m.studio});
            if(m.as_list.size()>=2) model.addRow(new Object[]{m.id,m.title,m.director.name,m.as_list.get(0).name+", "+m.as_list.get(1).name,m.year,m.genre,m.studio});
            */
        }
        
        table.setRowSelectionInterval(0, 0);
        //button_SearchMovie();
        
        table.getColumnModel().getColumn(0).setPreferredWidth(15);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(110);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(28);
        table.getColumnModel().getColumn(6).setPreferredWidth(150);
        table.getColumnModel().getColumn(7).setPreferredWidth(25);
        /*
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(200);
        table.getColumnModel().getColumn(6).setPreferredWidth(100);
        */
        button_SearchMovie();
        updateMovieTable();
    }
    
    public void setup_Background()
    {
        try{
            background_image = ImageIO.read(new File("VideoRentalSystem.png"));
            //background_image = ImageIO.read(new File("blue_background.png"));
        }catch(Exception exc){}
    }
    
    public void button_makeOrder()
    {
        if(VideoRentalSystem.current_customer.current_transaction.items.size()>0){
                VideoRentalSystem.current_customer.current_transaction.saveTransation();
                VideoRentalSystem.current_customer.current_transaction.calculateCost();
                VideoRentalSystem.current_customer.current_transaction.calculateDateString();

                VideoRentalSystem.current_customer.transaction_list.add(VideoRentalSystem.current_customer.current_transaction);
                
                
                
                        
                this.frame.setVisible(false);
                VideoRentalSystem.ref.frame.setVisible(true);

                VideoRentalSystem.ref.updateUsersTable();

                new CustomerRentHistory();
        }
    }
    
    public void button_RentMovie()
    {
        
        //int movie_rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        int movie_rowId=Integer.parseInt(""+this.table.getModel().getValueAt(table.getSelectedRow(), 0));
        
        String movie_title=""+this.table.getValueAt(table.getSelectedRow(), 1);
        
        //Movie movie_to_rent=Movie.movies.get(movie_rowId-1);
        Movie movie_to_rent=Movie.getMovieByTitle(movie_title);
                
        VideoRentalSystem.current_customer.current_transaction.addMovieToCart(movie_to_rent);
        button_SearchMovie();
    }
    
    public void table_selection_changed()
    {
        String list_of_actors="";
        try{
            for(int i=0;i<selected_movie.as_list.size();i++)
            {
                Actor a=selected_movie.as_list.get(i);
                if(a.deletedFromDatabase==false){
                    if(i<selected_movie.as_list.size()-1)
                    {
                        list_of_actors=list_of_actors+a.name+", ";
                    }else list_of_actors=list_of_actors+a.name;
                }
            }
        }catch(Exception exc){}
        
        
        
        this.l4.setText("<html><FONT COLOR=\"#000000\"><u>Movie:</u> "+this.table.getValueAt(table.getSelectedRow(), 1)
                +"<br><u>Director:</u> "+this.table.getValueAt(table.getSelectedRow(), 2)
                //+"<br><u>Actors:</u> "+this.table.getValueAt(table.getSelectedRow(), 3)
                +"<br><u>Actors:</u> "+list_of_actors
                
                +"<br><u>Year:</u> "+this.table.getValueAt(table.getSelectedRow(), 4)
                +"<br><u>Genre:</u> "+this.table.getValueAt(table.getSelectedRow(), 5)
                +"<br><u>Studio:</u> "+this.table.getValueAt(table.getSelectedRow(), 6)
                +"<br>"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"
                +"<br><br><br><br>"
                +"<FONT COLOR=\"#000000\"><u>Customer:</u> <FONT COLOR=\"#000066\">"+VideoRentalSystem.current_customer.name+" "+VideoRentalSystem.current_customer.surname
                +"<br><FONT COLOR=\"#000000\">Shooping cart: <FONT COLOR=\"#000066\">"+VideoRentalSystem.current_customer.current_transaction
                +"<br><br><FONT COLOR=\"#000000\"><u>Total cost:</u> "+VideoRentalSystem.current_customer.current_transaction.cost+" $"
                +"</html>");
                
        
        
        
        try{
            //BufferedImage myPicture = ImageIO.read(new File("indiana_jones_1.jpg"));
            BufferedImage myPicture = ImageIO.read(new File(this.selected_movie.poster_path));
            
            panel3.removeAll();
            picLabel = new JLabel(new ImageIcon(myPicture.getScaledInstance(69*3, 100*3, 1)));
            panel3.add(picLabel);
        }catch(Exception exc){}
        
    }
    
    public void button_ActorDataBase()
    {
        new ActorDataBase();
    }
    
    public void button_SearchMovie()
    {
        String stitle=search_title.getText();
        String sdirector=search_director.getText();
        String sactor=search_actor.getText();
        
        System.out.println("Search "+stitle+" "+sdirector+" "+sactor);
        
        int sid=(int)this.table.getValueAt(table.getSelectedRow(), 0);
        for(Movie m:Movie.movies)
        {
            if(m.id==sid)
            {
                selected_movie=m;
            }
        }
        
        Movie search_movie=null;
        for(Movie m:Movie.movies)
        {
            
            if(m.director.name.equals(sdirector)&&m.title.equals(stitle))
            {
                search_movie=m;
                selected_movie=m;
                System.out.println("Found "+sdirector);break;
            }
            
            for(Actor a:m.as_list)
            {
                if(a.name.equals(sactor)){search_movie=m;selected_movie=m;break;}
            }
            
            if(m.title.equals(stitle))
            {
                search_movie=m;
                selected_movie=m;
                System.out.println("Found "+stitle);break;
            }
            
            if(m.director.name.equals(sdirector))
            {
                search_movie=m;
                selected_movie=m;
                System.out.println("Found "+sdirector);break;
            }
        }
        
        
        
        
        
        
        if(search_movie!=null){
            for(int i=0;i<table.getRowCount();i++){
                //int val=(int)table.getModel().getValueAt(i, 0);
                //int val=table.convertRowIndexToView(i);
                int val=(int)table.getValueAt(i, 0);
                    if(search_movie.id==val)
                    {
                        table.setRowSelectionInterval(i, i);
                        table.scrollRectToVisible(new Rectangle(table.getCellRect(i, 0, true)));
                    }
            }
        }
        
        search_title.setText("");
        search_director.setText("");
        search_actor.setText("");
        
        table_selection_changed();
    }
    
    public void button_Back()
    {
        //this.frame.dispose();
        this.frame.setVisible(false);
        VideoRentalSystem.ref.frame.setVisible(true);
    }
    
    public void button_DeleteMovie()
    {
        int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        
        ArrayList<Movie> nlist=new ArrayList<Movie>();
        
        for(Movie m:Movie.movies)
        {
            
            if(m.id==rowId)
            {
                m.deleted=true;
                //Movie.saveAll_Movies_for_Serializable();
            }
            
            
            //if(m.id!=rowId)
            //{
                nlist.add(m);
            //}
        }
        Movie.movies=nlist;
        Movie.showMovies();
        updateMovieTable();
    }
    
    public void button_EditMovie()
    {
        System.out.println("edit");
        
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 0));
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 1));
        int rowId=0;
        
        try{
        rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        }catch(Exception exc){};
        
        new EditMovie(this,rowId);
    }
    
    
    public void button_AddNewMovie()
    {
        //new EnterNewCustomer(this);
        new AddNewMovie(this);
    }
    
    public void updateMovieTable()
    {
        
        
        DefaultTableModel model = new DefaultTableModel() {
            @Override
            public Class getColumnClass(int column) {
                switch (column) {
                    case 0:
                        return Integer.class;
                    case 1:
                        return String.class;
                    case 2:
                        return String.class;
                        case 3:
                        return String.class;
                        case 4:
                        return Integer.class;
                        case 5:
                        return String.class;
                        case 6:
                        return String.class;
                        case 7:
                        return Integer.class;
                    default:
                        return String.class;
                }
            }
        };
        
        model.addColumn("Id");
        model.addColumn("Title");
        model.addColumn("Director");
        model.addColumn("Actors");
        model.addColumn("Year");
        model.addColumn("Genre");
        model.addColumn("Studio");
        model.addColumn("Price");
        
        table=new JTable(model);
        
        table.setAutoCreateRowSorter(true);
        
        
        //Movie.movies.get(0).director.name="987";
        //Movie.movies.get(0).director.changeName("999");
        //Movie.movies.get(0).as_list=Movie.movies.get(10).as_list;
        Movie.showMovies();
        
        ArrayList<Actor> nlist=new ArrayList<Actor>();
        System.out.println(Movie.movies.get(0).as_list.get(0));
        nlist.add(Actor.actors.get(0));
        
        Movie.movies.get(0).as_list=nlist;
        
        System.out.println("************************************");
        System.out.println("************************************");
        Actor.showActors();
        Movie.showMovies();
        
        System.out.println("*************end********************");
        System.out.println("************************************");
        
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        for(Movie m:Movie.movies){
            if(m.deleted==false)
            {
                model.addRow(new Object[]{new Integer(m.id),m.title,m.director.name,m.getList(),m.year,m.genre,m.studio,m.price});
            }
        }
        
        
        
        
        table.setRowSelectionInterval(0, 0);
        
        table.getColumnModel().getColumn(0).setPreferredWidth(15);
        table.getColumnModel().getColumn(1).setPreferredWidth(150);
        table.getColumnModel().getColumn(2).setPreferredWidth(110);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(4).setPreferredWidth(28);
        table.getColumnModel().getColumn(6).setPreferredWidth(150);
        table.getColumnModel().getColumn(7).setPreferredWidth(25);
        
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,200));
        
        panel.removeAll();
        panel2.removeAll();
        panel3.removeAll();
        
        panel.add(b5);
        panel.add(b30);
        panel.add(b1);
        panel.add(b2);
        panel.add(b3);
        panel.add(b20);
        panel.add(b10);
        
        panel.add(sp);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        panel.add(l1);panel.add(search_title);
        panel.add(l2);panel.add(search_director);
        panel.add(l3);panel.add(search_actor);
        panel.add(b4);
        
        panel.add(panel2);
        //panel2.setLayout(new GridLayout(1,1));
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        panel2.setLayout(new FlowLayout(FlowLayout.LEFT));
        //panel2.setLayout(new GridLayout(1,0));
        panel2.add(l4);
        
        panel2.add(panel3);
        panel3.setLayout(new FlowLayout(FlowLayout.LEFT));
        frame.pack();
        frame.show();
        
        try{
            //BufferedImage myPicture = ImageIO.read(new File("indiana_jones_1.jpg"));
            BufferedImage myPicture = ImageIO.read(new File(this.selected_movie.poster_path));
            
            picLabel = new JLabel(new ImageIcon(myPicture.getScaledInstance(69*3, 100*3, 1)));
            panel3.add(picLabel);
        }catch(Exception exc){}
        
        
        
        MouseListener l=new MouseListener()
        {
            @Override
            public void mouseClicked(MouseEvent me) {
                
                 //table_selection_changed();
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                    button_SearchMovie();
            }

            @Override
            public void mouseEntered(MouseEvent me) {
                
            }

            @Override
            public void mouseExited(MouseEvent me) {
                
            }
        };
        table.addMouseListener(l);
        
        table.setRowSelectionInterval(0,0);
        
        this.search_actor.setText("");
        this.search_director.setText("");
        this.search_title.setText("");
        
        button_SearchMovie();
        
        
    }
    
    public static void main(String[] args) {
        
        
        
        //vrs.thread=new Thread(vrs);
        //vrs.thread.start();
        
        
         
         //String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
         //String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
         //vrs.table=new JTable(data_persons,col_names);
         
         
        
         
        
        
        //table=new JTable(50,5);
        
        
        /*
        vrs.table.getColumnModel().getColumn(0).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(1).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(2).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(3).setPreferredWidth(30);
        vrs.table.getColumnModel().getColumn(4).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(5).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(6).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(7).setPreferredWidth(10);
        */
        
        
        
        
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        System.out.println("123");
    }

    @Override
    public void mousePressed(MouseEvent me) {
        System.out.println("20");
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        System.out.println("30");
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        System.out.println("10");
        //this.table_selection_changed();
    }

    @Override
    public void mouseExited(MouseEvent me) {
        System.out.println("11");
    }
}
