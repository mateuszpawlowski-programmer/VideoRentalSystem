/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import static java.util.Calendar.DAY_OF_MONTH;
import static java.util.Calendar.MONTH;
import static java.util.Calendar.YEAR;
import java.util.Date;
import static jdk.nashorn.internal.parser.DateParser.DAY;


public class Transaction implements Serializable{

private static final long SerialVersionUID = 10l;

public Integer id;
public Person customer;

public ArrayList<Movie> items=new ArrayList<Movie>();

public long date_start=0;
public long now=0;

public String date_start_String="";
public String now_String="";

public double additional_cost=0;

public double price_for_extra_day=1.0;

public int days=0;
public int extra_days=0;

public double cost;

public String paid="Unpaid";

public static int maxId=0;

public boolean transaction_closed=false;
public String transaction_closed_String="Unclosed";

public static ArrayList<Transaction> all_transactions=new ArrayList<Transaction>();

Transaction(Person customer)
{
    id=maxId;
    this.customer=customer;
    maxId=maxId+1;
    
    Transaction.all_transactions.add(this);
}

public String toString()
{
    String movies_in_cart="";
    
    cost=0;
    
    int i=0;
    for(Movie m:items)
    {
        i++;
        movies_in_cart=movies_in_cart+" "+m.title;
        if(i==5||i==10||i==15||i==20){movies_in_cart=movies_in_cart+"<br>";}
        
        cost=cost+m.price;
    }
    
    if(items.size()==0) movies_in_cart="empty";
    
    return movies_in_cart;
}

public static void saveAll_Transaction_for_Serializable()
{
    for(Transaction t:Transaction.all_transactions)
    {
        t.saveTransaction_for_Serializable();
    }
}

public void saveTransaction_for_Serializable()
{
        try{
            FileOutputStream fos 
                = new FileOutputStream("Transaction_id_"+this.id+".txt"); 
            ObjectOutputStream oos 
                = new ObjectOutputStream(fos); 
            oos.writeObject(this); 
            oos.close(); 
            System.out.println("Save transaction: "+this.id);
        }catch(Exception exc){System.out.println("Exception: "+exc);}
}

public static void showAllTransactions()
{
    System.out.println("Transaction list size "+Transaction.all_transactions.size());
    
    for(Transaction t:Transaction.all_transactions)
    {
        System.out.println("Transaction "+t.id+" "+t.customer.name+" movies"+t.items.size()+" "+t.transaction_closed_String);
        //System.out.println("Transaction "+t.id+" "+t.customer);
    }
}

public static void loadAllTransactions()
{
    for(int nr=1;nr<100;nr++){
                    try{
                        FileInputStream fis 
                            = new FileInputStream("Transaction_id_"+nr+".txt"); 
                        ObjectInputStream ois = new ObjectInputStream(fis); 


                        //System.out.println("number "+nr);

                        Transaction.loadTransaction(nr);
                    }catch(Exception exc)
                    {
                        //System.out.println("error "+exc);
                    }
        }
}

public static void loadTransaction(int id)
    {
        try{
        FileInputStream fis 
            = new FileInputStream("Transaction_id_"+id+".txt"); 
        ObjectInputStream ois = new ObjectInputStream(fis); 
        
        Transaction t=(Transaction)ois.readObject();
        
        Transaction.all_transactions.add(t);
        
        ois.close(); 
            
        /*
        Transaction nt=new Transaction(t.customer);
        
        
        
        
        nt.customer=t.customer;
        nt.items=t.items;
        nt.date_start=t.date_start;
        nt.now=t.now;
        nt.date_start_String=t.date_start_String;
        nt.now_String=t.now_String;
        nt.additional_cost=t.additional_cost;
        nt.price_for_extra_day=t.price_for_extra_day;
        nt.days=t.days;
        nt.extra_days=t.extra_days;
        nt.cost=t.cost;
        nt.paid=t.paid;
        nt.transaction_closed=t.transaction_closed;
        nt.transaction_closed_String=t.transaction_closed_String;
        */
        //t.customer.transaction_list.add(nt);
        
        System.out.println("Load transaction: "+t.id);
                //EnterNewCustomer.maxId=10;
        }catch(Exception exc){System.out.println("Load transaction Exception: "+exc);}
    }

public void addMovieToCart(Movie m)
{
    items.add(m);
}

public void clearCart()
{
    items=new ArrayList<Movie>();
}

public void saveTransation()
{
    //date_start=System.currentTimeMillis();
    Calendar c=Calendar.getInstance();
    //c.set(2024,0,1);

    date_start=c.getTimeInMillis();
    
    System.out.println(c.getTime());
}

public void saveTransation_for_demo_1()
{
    //date_start=System.currentTimeMillis();
    Calendar c=Calendar.getInstance();
    
    for(int i=0;i<10;i++)
    {
        c.roll(Calendar.DAY_OF_YEAR, false);
    }
    
    //c.set(2024,0,1);

    date_start=c.getTimeInMillis();
    
    System.out.println(c.getTime());
}

public void saveTransation_for_demo_2()
{
    //date_start=System.currentTimeMillis();
    Calendar c=Calendar.getInstance();
    
    for(int i=0;i<11;i++)
    {
        c.roll(Calendar.DAY_OF_YEAR, false);
    }
    
    //c.set(2024,0,1);

    date_start=c.getTimeInMillis();
    
    System.out.println(c.getTime());
}

public void calculateDateString()
{
    SimpleDateFormat sdf = new SimpleDateFormat("dd / MM / yyyy");
        
    Calendar c=Calendar.getInstance();
    c.setTimeInMillis(date_start);
    
    String formattedDate = sdf.format(c.getTime());
    date_start_String=formattedDate;

    Calendar c2=Calendar.getInstance();
    c2.setTimeInMillis(now);
    String formattedDate2 = sdf.format(c2.getTime());
    now_String=formattedDate2;
}

public void calculateCost()
{
    if(transaction_closed==false){
            now=System.currentTimeMillis();





            long diff=now-date_start;

            days=(int)(diff/86400000);
            
            if (days>7)
            {
                extra_days=days-7;
            }else extra_days=0;

            additional_cost=0;

            additional_cost=extra_days*price_for_extra_day*items.size();

            System.out.println("days "+days);
            System.out.println("total cost "+additional_cost);
            //System.out.println();


            if(extra_days>0){paid="Unpaid";}
            if(extra_days==0){paid="Unreturned";}
    }else
    {
        if(extra_days>0) paid="OK Paid";
        if(extra_days==0) paid="OK Returned";
        transaction_closed_String="Closed";
    }
}

}
