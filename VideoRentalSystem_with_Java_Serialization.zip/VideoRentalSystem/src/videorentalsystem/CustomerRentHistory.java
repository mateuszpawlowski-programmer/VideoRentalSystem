package videorentalsystem;

import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.Graphics;
import java.awt.Rectangle;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.util.ArrayList;
import javax.imageio.ImageIO;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author M
 */
public class CustomerRentHistory extends JFrame implements MouseListener{

    public static CustomerRentHistory ref;
    
    public BufferedImage background_image;
    
    public JPanel panel=new JPanel(){@Override
        public void paint(Graphics g){
            super.paint(g);

            int transparency = 20; //0-255, 0 is invisible, 255 is opaque
            int colorMask = 0x00FFFFFF; //AARRGGBB
            int alphaShift = 24;

                    for(int y = 0; y < background_image.getHeight(); y++){
                        for(int x = 0; x < background_image.getWidth(); x++){
                            background_image.setRGB(x, y, (background_image.getRGB(x, y) & colorMask) | (transparency << alphaShift));
                        }
                    }

            g.drawImage(background_image, 0, 0, getWidth(), getHeight(), this);
        }
    };
    
    public JFrame frame=new JFrame("Customer Rent History");
    //public Thread thread;
    public JTable table=new JTable();
    public JScrollPane sp=new JScrollPane();
    
    
    public JButton b1=new JButton("Pay / Return Movie.");
    public JButton b2=new JButton("Back.");
    
    
    public JLabel l1=new JLabel("");
    public JLabel l2=new JLabel("");
    
    public static Person current_customer;
    
    public static MovieDataBase movie_data_base_ref;
    
    CustomerRentHistory()
    {
        ref=this;
        
        setup_Background();
        
        current_customer=VideoRentalSystem.current_customer;
        
        panel.add(l1);
        l1.setText("Rent History: "+VideoRentalSystem.current_customer.name+" "+VideoRentalSystem.current_customer.surname);
        
        panel.add(b1);
        panel.add(b2);
        
        
                
        ActionListener b1_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                //button_EnterNewCustomer();
                button_Pay();
            }
        };
        
        b1.addActionListener(b1_action);
        
        ActionListener b2_action=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_Back();
            }
        };
        
        b2.addActionListener(b2_action);
        
        /*
        String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
        String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
        
        table=new JTable(data,col_names);
        //DefaultTableModel dtm=(DefaultTableModel)table.getModel();
        
        
        //table=new JTable(50,5);
        
        //table.setBounds(30, 40, 200, 300);
        JScrollPane sp = new JScrollPane(table);
        
        
        table.getColumnModel().getColumn(0).setPreferredWidth(100);
        table.getColumnModel().getColumn(1).setPreferredWidth(10);
        table.getColumnModel().getColumn(2).setPreferredWidth(20);
        table.getColumnModel().getColumn(3).setPreferredWidth(30);
        table.getColumnModel().getColumn(4).setPreferredWidth(10);
        
        
        this.panel.add(sp);
        */
        
        
        
        
        frame = this;
        panel.setPreferredSize(new Dimension(820,600));
        
        frame = new JFrame("Mateusz Pawlowski. Video Rental System. 2024. Rent history.");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        panel.setSize(800, 600);
        frame.setLocation(500, 300);
       
        
        
        
        System.out.println(""+VideoRentalSystem.current_customer.name);
        
        Person.showPersons();
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Id");
        model.addColumn("Date start");
        model.addColumn("Date now");
        model.addColumn("Extra days > 7");
        //model.addColumn("Birth");
        model.addColumn("Nr. of Movies");
        model.addColumn("Additional cost");
        model.addColumn("Status");
        model.addColumn("Closed");
        
        table=new JTable(model);
        
        
        
        //table.setEnabled(false);
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,200));
        panel.add(sp);
        panel.setLayout(new FlowLayout(FlowLayout.LEFT));
        
        panel.add(l2);
        
        frame.pack();
        frame.show();
        
        for(Transaction t:VideoRentalSystem.current_customer.transaction_list)
        {
            model.addRow(new Object[]{t.id,t.date_start_String,t.now_String,t.days,t.items.size(),t.additional_cost,t.paid,t.transaction_closed_String});
        }
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        
        if(VideoRentalSystem.current_customer.transaction_list.size()>0) 
        {
            table.setRowSelectionInterval(0, 0);
            button_History_Selected();
        }
        
        table.getColumnModel().getColumn(0).setPreferredWidth(10);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(200);
        
        MouseListener l=new MouseListener()
        {
            @Override
            public void mouseClicked(MouseEvent me) {
                 
                 //table_selection_changed();
            }

            @Override
            public void mousePressed(MouseEvent me) {
                
            }

            @Override
            public void mouseReleased(MouseEvent me) {
                button_History_Selected();
            }

            @Override
            public void mouseEntered(MouseEvent me) {
                
            }

            @Override
            public void mouseExited(MouseEvent me) {
                
            }
        };
        table.addMouseListener(l);
    }
    
    public void setup_Background()
    {
        try{
            background_image = ImageIO.read(new File("VideoRentalSystem.png"));
            //background_image = ImageIO.read(new File("blue_background.png"));
        }catch(Exception exc){}
    }
    
    public void  button_History_Selected()
    {
                int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));

                for(Transaction t:VideoRentalSystem.current_customer.transaction_list)
                {
                    if(t.id==rowId)
                    {
                        String movies_from_transaction="Movies: ";
                        for(Movie m:t.items){
                            movies_from_transaction=movies_from_transaction+" \'"+m.title+"\'";
                        }
                        l2.setText(movies_from_transaction);
                    }
                }
    }
    
    public void button_Pay()
    {
        if(VideoRentalSystem.current_customer.transaction_list.size()>0){
                int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));

                for(Transaction t:VideoRentalSystem.current_customer.transaction_list)
                {
                    if(t.id==rowId)
                    {
                        t.transaction_closed=true;
                        t.calculateCost();
                    }
                }
                
                VideoRentalSystem.ref.updateUsersTable();
                
                this.frame.dispose();
                new CustomerRentHistory();
        }
    }
    
    public void button_Back()
    {
        this.frame.dispose();
    }
    
    public void button_MovieDataBase()
    {
        //new MovieDataBase();
            
            int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
            System.out.println(""+rowId+" "+table.getValueAt(table.getSelectedRow(),1));
            
            this.current_customer=Person.getCustomer(rowId);
            
            
        if(MovieDataBase.created==false)
        {
            current_customer.current_transaction=new Transaction(current_customer);
            
            this.frame.setVisible(false);
            movie_data_base_ref=new MovieDataBase();
        }
        
        if(MovieDataBase.created==true)
        {
            current_customer.current_transaction=new Transaction(current_customer);
            
            this.frame.setVisible(false);
            MovieDataBase.ref.frame.setVisible(true);
            movie_data_base_ref.button_SearchMovie();
            
        }
    }
    
    public void button_SearchCustomer()
    {
                        table.setRowSelectionInterval(0, 0);
                        table.scrollRectToVisible(new Rectangle(table.getCellRect(0, 0, true)));
    }
    
    public void button_DeleteCustomer()
    {
        int rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        
        ArrayList<Person> nlist=new ArrayList<Person>();
        
        for(Person p:Person.persons)
        {
            if(p.id!=rowId)
            {
                nlist.add(p);
            }
        }
        Person.persons=nlist;
        Person.showPersons();
        //updateUsersTable();
    }
    
    public void button_EditCustomer()
    {
        System.out.println("edit");
        
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 0));
        //System.out.println(""+this.table.getValueAt(table.getSelectedRow(), 1));
        int rowId=0;
        
        try{
        rowId=Integer.parseInt(""+this.table.getValueAt(table.getSelectedRow(), 0));
        }catch(Exception exc){};
        
        //new EditCustomer(this,rowId);
    }
    
    
    public void button_EnterNewCustomer()
    {
        //new EnterNewCustomer(this);
    }
    
    public void updateRentTable()
    {
        
        panel.removeAll();
        
         panel.add(l1);
        l1.setText(""+VideoRentalSystem.current_customer.name+" "+VideoRentalSystem.current_customer.surname+"\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"+
                "\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0"+
                "\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0\u00A0");
        
        panel.add(b1);
        panel.add(b2);
        
         frame = this;
        panel.setPreferredSize(new Dimension(820,600));
        
        frame = new JFrame("Mateusz Pawlowski. Video Rental System. 2024. Rent history.");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.getContentPane().add(panel);
        panel.setSize(800, 600);
        frame.setLocation(500, 300);
       
        
        
        
        System.out.println(""+VideoRentalSystem.current_customer.name);
        
        Person.showPersons();
        
        DefaultTableModel model = new DefaultTableModel();
        model.addColumn("Id");
        model.addColumn("Date start");
        model.addColumn("Date now");
        model.addColumn("Extra days > 7");
        //model.addColumn("Birth");
        model.addColumn("Nr. of Movies");
        model.addColumn("Additional cost");
        model.addColumn("Returned");
        
        table=new JTable(model);
        
        
        
        //table.setEnabled(false);
        
        sp = new JScrollPane(table);
        //table.setPreferredSize(new Dimension(800,600));
        sp.setPreferredSize(new Dimension(800,200));
        panel.add(sp);
        panel.setLayout(new FlowLayout(FlowLayout.RIGHT));
        
        frame.pack();
        frame.show();
        
        for(Transaction t:VideoRentalSystem.current_customer.transaction_list)
        {
            model.addRow(new Object[]{t.id,t.date_start_String,t.now_String,t.days,t.items.size(),t.additional_cost,t.paid});
        }
        //DefaultTableModel model = (DefaultTableModel) table.getModel();
        //model.addRow(new Object[]{"Column 1", "Column 2", "Column 3","Column 4","Column 5","Column 6","Column 7","Column 8"});
        
        //table.setRowSelectionInterval(0, 0);
        
        table.getColumnModel().getColumn(0).setPreferredWidth(10);
        table.getColumnModel().getColumn(3).setPreferredWidth(150);
        table.getColumnModel().getColumn(5).setPreferredWidth(200);
    }
    
    public static void main(String[] args) {
        VideoRentalSystem vrs=new VideoRentalSystem();
        
        
        //vrs.thread=new Thread(vrs);
        //vrs.thread.start();
        
        
         
         //String[][] data={{"Id","Name","Surname","Birth date","Address","City","Email","Phone"}};
         //String[] col_names={"Id","Name","Surname","Birth date","Address","City","Email","Phone"};
        
         //vrs.table=new JTable(data_persons,col_names);
         
         
        
         
        
        
        //table=new JTable(50,5);
        
        
        /*
        vrs.table.getColumnModel().getColumn(0).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(1).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(2).setPreferredWidth(100);
        vrs.table.getColumnModel().getColumn(3).setPreferredWidth(30);
        vrs.table.getColumnModel().getColumn(4).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(5).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(6).setPreferredWidth(10);
        vrs.table.getColumnModel().getColumn(7).setPreferredWidth(10);
        */
        
        
        
        
    }

    @Override
    public void mouseClicked(MouseEvent me) {
        
    }

    @Override
    public void mousePressed(MouseEvent me) {
        
    }

    @Override
    public void mouseReleased(MouseEvent me) {
        
    }

    @Override
    public void mouseEntered(MouseEvent me) {
        
    }

    @Override
    public void mouseExited(MouseEvent me) {
        
    }
 
}
