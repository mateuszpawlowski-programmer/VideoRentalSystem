/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;


import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class EnterNewCustomer extends JFrame {
    
    public JPanel panel=new JPanel();
    
    public JPanel panel_title=new JPanel();
    
    public JPanel panel_1=new JPanel();
    public JPanel panel_2=new JPanel();
    public JPanel panel_3=new JPanel();
    public JPanel panel_4=new JPanel();
    public JPanel panel_5=new JPanel();
    public JPanel panel_6=new JPanel();
    public JPanel panel_7=new JPanel();
    public JPanel panel_8=new JPanel();
    
    
    public JButton button_enter=new JButton("Enter");
    public JButton button_cancel=new JButton("Cancel");
    
    public JFrame frame=new JFrame("Enter new customer.");
    public JLabel label1=new JLabel("Enter new customer");
    
    public JLabel elabel=new JLabel("");
    public JLabel elabel2=new JLabel(" ");
    public JLabel elabel3=new JLabel("");
    public JLabel elabel4=new JLabel("");
    public JLabel elabel5=new JLabel("");
    
    public JTextField name=new JTextField(20);
    public JTextField surname=new JTextField(20);
    public JTextField birth=new JTextField(20);
    public JTextField address=new JTextField(20);
    public JTextField city=new JTextField(20);
    public JTextField email=new JTextField(20);
    public JTextField phone=new JTextField(20);
    
    public JLabel l1=new JLabel("Name");
    public JLabel l2=new JLabel("Surname");
    public JLabel l3=new JLabel("Birth date");
    public JLabel l4=new JLabel("Address");
    public JLabel l5=new JLabel("City");
    public JLabel l6=new JLabel("Email");
    public JLabel l7=new JLabel("Phone");
    
    public VideoRentalSystem sys_ref;
    
    public static int maxId;
    
    EnterNewCustomer(VideoRentalSystem sr)
    {
        sys_ref=sr;
        
        //frame.setPreferredSize(new Dimension(500,300));
        panel.setPreferredSize(new Dimension(500,250));
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(700, 450);
        
        
        
        
        //panel.setLayout(new GridLayout(8,0));
        
        panel_1.setLayout(new GridLayout(1,0));
        panel_2.setLayout(new GridLayout(1,0));
        panel_3.setLayout(new GridLayout(1,0));
        panel_4.setLayout(new GridLayout(1,0));
        panel_5.setLayout(new GridLayout(1,0));
        panel_6.setLayout(new GridLayout(1,0));
        panel_7.setLayout(new GridLayout(1,0));
        panel_8.setLayout(new GridLayout(0,6));
        
                
        panel_title.add(label1);
        panel_1.add(l1);panel_1.add(name);
        panel_2.add(l2);panel_2.add(surname);
        panel_3.add(l3);panel_3.add(birth);
        panel_4.add(l4);panel_4.add(address);
        panel_5.add(l5);panel_5.add(city);
        panel_6.add(l6);panel_6.add(email);
        panel_7.add(l7);panel_7.add(phone);
        
        //frame.getContentPane().add(panel);
        frame.add(panel);
        
        panel.add(panel_title);
        panel.add(panel_1);
        panel.add(panel_2);
        panel.add(panel_3);
        panel.add(panel_4);
        panel.add(panel_5);
        panel.add(panel_6);
        panel.add(panel_7);
        
        panel_8.add(elabel);
        panel_8.add(elabel2);
        panel_8.add(elabel3);
        panel_8.add(elabel4);
        
        
        panel_8.add(button_enter);
        panel_8.add(button_cancel);
        
        panel.add(panel_8);
        
        ActionListener b_enter=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_enter();
            }
        };
        
        this.button_enter.addActionListener(b_enter);
        
        
        ActionListener b_cancel=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_cancel();
            }
        };
        
        this.button_cancel.addActionListener(b_cancel);
        
        frame.pack();
        frame.show();
    }
    
    public void button_enter()
    {
        maxId=maxId+1;
        new Person(maxId,this.name.getText(),this.surname.getText(),this.birth.getText(),this.address.getText(),this.city.getText(),this.email.getText(),this.phone.getText());
        
        sys_ref.updateUsersTable();
        this.frame.dispose();
    }
    
    public void button_cancel()
    {
        this.frame.dispose();
    }
}
