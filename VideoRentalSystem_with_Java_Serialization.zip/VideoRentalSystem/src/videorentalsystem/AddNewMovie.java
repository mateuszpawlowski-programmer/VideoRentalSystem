/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package videorentalsystem;


import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JList;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextField;
import javax.swing.ListSelectionModel;

public class AddNewMovie extends JFrame {
    
    public JPanel panel=new JPanel();
    
    public JPanel panel_title=new JPanel();
    
    public JPanel panel_1=new JPanel();
    public JPanel panel_2=new JPanel();
    public JPanel panel_3=new JPanel();
    public JPanel panel_33=new JPanel();
    
    public JPanel panel_4=new JPanel();
    public JPanel panel_5=new JPanel();
    public JPanel panel_6=new JPanel();
    public JPanel panel_7=new JPanel();
    public JPanel panel_8=new JPanel();
    public JPanel panel_9=new JPanel();
    
    
    public JButton button_enter=new JButton("Enter");
    public JButton button_cancel=new JButton("Cancel");
    
    public JFrame frame=new JFrame("Add new Movie.");
    public JLabel label1=new JLabel("Add new Movie");
    
    public JLabel elabel=new JLabel("");
    public JLabel elabel2=new JLabel(" ");
    public JLabel elabel3=new JLabel("");
    public JLabel elabel4=new JLabel("");
    public JLabel elabel5=new JLabel("");
    
    public JTextField title=new JTextField(20);
    public JTextField director=new JTextField(20);
    public JTextField actors=new JTextField(20);
    public JTextField year=new JTextField(20);
    public JTextField genre=new JTextField(20);
    public JTextField studio=new JTextField(20);
    public JTextField poster=new JTextField(20);
    public JTextField price=new JTextField(20);
    
    public JLabel l1=new JLabel("Title");
    public JLabel l2=new JLabel("Director");
    public JLabel l3=new JLabel("Actors");
    
    public JList jl0=new JList();
    public JList jl1=new JList();
    
    public JScrollPane scrollableList0;
    public JScrollPane scrollableList1;
    
    public JLabel l4=new JLabel("Year");
    public JLabel l5=new JLabel("Genre");
    public JLabel l6=new JLabel("Studio");
    public JLabel l7=new JLabel("Poster");
    public JLabel l8=new JLabel("Price");
        
    public MovieDataBase sys_ref;
    
    public static int maxId=18;
    
    AddNewMovie(MovieDataBase mdbr)
    {
        
        sys_ref=mdbr;
        
        //frame.setPreferredSize(new Dimension(500,300));
        panel.setPreferredSize(new Dimension(500,380));
        
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        frame.setLocation(700, 450);
        
        
        
        
        //panel.setLayout(new GridLayout(8,0));
        
        panel_1.setLayout(new GridLayout(1,0));
        
        //panel_2.setLayout(new GridLayout(1,0));
        //panel_3.setLayout(new GridLayout(1,0));
        
        
        panel_4.setLayout(new GridLayout(1,0));
        panel_5.setLayout(new GridLayout(1,0));
        panel_6.setLayout(new GridLayout(1,0));
        panel_7.setLayout(new GridLayout(1,0));
        panel_8.setLayout(new GridLayout(1,0));
        
        panel_9.setLayout(new GridLayout(0,6));
        
                
        panel_title.add(label1);
        panel_1.add(l1);panel_1.add(title);
        
        jl0=new JList(Actor.actors.toArray());
        jl0.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
        
        scrollableList0 = new JScrollPane(jl0);
        panel_2.add(l2);panel_2.add(scrollableList0);
        
        
        //panel_2.add(l2);panel_2.add(director);
        //panel_3.add(l3);panel_3.add(actors);
        
        jl1=new JList(Actor.actors.toArray());
        scrollableList1 = new JScrollPane(jl1);
        panel_3.add(l3);panel_3.add(scrollableList1);
        
        
        panel_4.add(l4);panel_4.add(year);
        panel_5.add(l5);panel_5.add(genre);
        panel_6.add(l6);panel_6.add(studio);
        panel_7.add(l7);panel_7.add(poster);
        panel_8.add(l8);panel_8.add(price);
        
        //frame.getContentPane().add(panel);
        frame.add(panel);
        
        panel.add(panel_title);
        panel.add(panel_1);
        panel.add(panel_2);
        panel.add(panel_3);
        
        panel.add(panel_4);
        panel.add(panel_5);
        panel.add(panel_6);
        panel.add(panel_7);
        panel.add(panel_8);
        
        panel_9.add(elabel);
        panel_9.add(elabel2);
        panel_9.add(elabel3);
        panel_9.add(elabel4);
        
        
        panel_9.add(button_enter);
        panel_9.add(button_cancel);
        
        panel.add(panel_9);
        
        ActionListener b_enter=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_enter();
            }
        };
        
        this.button_enter.addActionListener(b_enter);
        
        ActionListener b_cancel=new ActionListener()
        {
            @Override
            public void actionPerformed(ActionEvent ae) {
                button_cancel();
            }
        };
        
        this.button_cancel.addActionListener(b_cancel);
        
        frame.pack();
        frame.show();
    }
    
    public void button_enter()
    {
        String director_name=""+jl0.getSelectedValue();
        
        System.out.println(""+jl0.getSelectedValue());
        System.out.println(""+jl1.getSelectedValuesList());
        
        ArrayList<Actor> movie_actors_list=new ArrayList<Actor>();
        for(int i=0;i<jl1.getSelectedValuesList().size();i++)
        {
            String actor_name=""+jl1.getSelectedValuesList().get(i);
            movie_actors_list.add(Actor.getActor(actor_name));
        }
        
        maxId=maxId+1;
        //new Person(maxId,this.name.getText(),this.surname.getText(),this.birth.getText(),this.address.getText(),this.city.getText(),this.email.getText(),this.phone.getText());
        
        //list.add(Actor.getActor("Angelina Jolie"));
        
        //new Movie(maxId,"Tomb Raider 2",Actor.getActor("Angelina Jolie"),list,"2024","Action","Paramount Pictures","tomb_raider.png");
        new Movie(maxId,title.getText(),Actor.getActor(director_name),movie_actors_list,year.getText(),genre.getText(),studio.getText(),poster.getText(),Double.parseDouble(price.getText()));
        
        sys_ref.last_added_movie_record=maxId-1;
        
        sys_ref.updateMovieTable();
        this.frame.dispose();
    }
    
    public void button_cancel()
    {
        this.frame.dispose();
    }
}
